/**
 * GitPress Editor — bootstrap.
 *
 * Responsibilities:
 *   1. Verify the localized config is present.
 *   2. Mount the floating launcher button and panel into #gitpress-editor-root.
 *   3. Enable the element-selection editor when the panel is opened.
 */
(function () {
  'use strict';

  if (typeof window.GitPressEditor === 'undefined') return;

  var App = window.GitPressEditorApp;
  if (!App || !App.editor || !App.panel) return;

  document.addEventListener('DOMContentLoaded', init);
  if (document.readyState === 'interactive' || document.readyState === 'complete') {
    init();
  }

  var initialized = false;
  function init() {
    if (initialized) return;
    initialized = true;

    var root = document.getElementById('gitpress-editor-root');
    if (!root) return;

    // Launcher button — stays visible on the page.
    var launcher = document.createElement('button');
    launcher.type = 'button';
    launcher.className = 'gp-editor-launcher';
    launcher.setAttribute('aria-label', (window.GitPressEditor.i18n && window.GitPressEditor.i18n.launch) || 'Edit');
    launcher.innerHTML = '<span class="gp-editor-launcher__icon" aria-hidden="true">&#9998;</span>';
    root.appendChild(launcher);

    // Mount the panel inside the root.
    App.panel.mount(root);

    // Activate element selection whenever the panel is open.
    launcher.addEventListener('click', function () {
      App.editor.setEnabled(true);
      App.panel.open();
    });
  }
})();
