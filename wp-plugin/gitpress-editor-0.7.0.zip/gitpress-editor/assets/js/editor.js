/**
 * GitPress Editor — element selection & highlight module (v0.2.0).
 *
 * Requires that target elements carry a `data-edit` attribute. Generic
 * selectors and runtime id generation are gone.
 *
 * Attaches to window.GitPressEditorApp as .editor.
 * Exposes: init(callbacks), setEnabled(bool), deselect(path), clearAll(),
 *          applyPreview(edits), revertPreview().
 */
(function () {
  'use strict';

  var App = (window.GitPressEditorApp = window.GitPressEditorApp || {});

  var hoveredEl = null;
  var enabled = false;
  var locked = false; // When true, prevent deselection (AI review in progress)
  var lockedPaths = new Set(); // Paths that have active AI edits (deselection blocked)
  var handlers = null;
  var listenersBound = false;

  // Snapshot map for preview/revert — key: path -> {text, style, className, attrs}
  var snapshots = Object.create(null);

  // Nodes created by applyPreview via insert edits. Removed on revertPreview.
  var insertedNodes = [];

  // Tags allowed for insertion — must stay in sync with class-rest-api.php.
  var ALLOWED_INSERT_TAGS = ['img', 'p', 'h2', 'h3', 'hr'];
  var ALLOWED_INSERT_POSITIONS = ['before', 'after', 'inside'];

  // Whitelist of attribute keys that applyPreview can set. Must stay in sync
  // with class-rest-api.php::ALLOWED_ATTR_KEYS and class-content-updater.php.
  var ALLOWED_ATTR_KEYS = [
    'src', 'alt', 'srcset', 'sizes', 'width', 'height',
    'href', 'title', 'target', 'rel'
  ];

  function escapeCss(value) {
    if (typeof window.CSS !== 'undefined' && typeof window.CSS.escape === 'function') {
      return window.CSS.escape(value);
    }
    return String(value).replace(/[^a-zA-Z0-9_-]/g, function (c) { return '\\' + c; });
  }

  function findByPath(path) {
    if (!path) return null;
    try {
      return document.querySelector('[data-edit="' + escapeCss(path) + '"]');
    } catch (_) {
      return null;
    }
  }

  function setLeadingText(el, text) {
    // Remove all text/cdata children, then prepend new text as a single text node.
    for (var i = el.childNodes.length - 1; i >= 0; i--) {
      var n = el.childNodes[i];
      if (n.nodeType === Node.TEXT_NODE || n.nodeType === Node.CDATA_SECTION_NODE) {
        el.removeChild(n);
      }
    }
    if (text !== undefined && text !== null) {
      el.insertBefore(document.createTextNode(String(text)), el.firstChild);
    }
  }

  function mergeStyle(el, styleMap) {
    if (!styleMap || typeof styleMap !== 'object') return;
    for (var prop in styleMap) {
      if (!Object.prototype.hasOwnProperty.call(styleMap, prop)) continue;
      var value = styleMap[prop];
      if (typeof prop !== 'string' || typeof value !== 'string') continue;
      try {
        // Use 'important' priority so preview styles override theme CSS
        // that may use !important. The snapshot restores the original
        // style attribute on revert, so this is safe.
        el.style.setProperty(prop, value, 'important');
        // When the AI/user changes `color`, also reset -webkit-text-fill-color
        // and neutralize any gradient/background-clip text effect inherited
        // from preset classes (e.g. gp-text-rainbow). Without this the new
        // color is silently invisible because the class keeps the fill
        // transparent with a clipped background-image.
        if (prop === 'color') {
          el.style.setProperty('-webkit-text-fill-color', value, 'important');
          el.style.setProperty('background-image', 'none', 'important');
          el.style.setProperty('-webkit-background-clip', 'border-box', 'important');
          el.style.setProperty('background-clip', 'border-box', 'important');
        }
      } catch (_) {}
    }
  }

  function addClasses(el, classes) {
    if (!Array.isArray(classes)) return;
    classes.forEach(function (c) {
      if (typeof c === 'string' && /^[a-zA-Z][a-zA-Z0-9_-]*$/.test(c)) {
        el.classList.add(c);
      }
    });
  }

  function removeClasses(el, classes) {
    if (!Array.isArray(classes)) return;
    classes.forEach(function (c) {
      if (typeof c === 'string') el.classList.remove(c);
    });
  }

  function snapshot(el) {
    var path = el.getAttribute('data-edit');
    if (!path || snapshots[path]) return;
    var attrs = {};
    for (var i = 0; i < ALLOWED_ATTR_KEYS.length; i++) {
      var key = ALLOWED_ATTR_KEYS[i];
      if (el.hasAttribute(key)) {
        attrs[key] = el.getAttribute(key);
      }
    }
    snapshots[path] = {
      text: el.textContent,
      style: el.getAttribute('style') || '',
      className: el.getAttribute('class') || '',
      attrs: attrs
    };
  }

  function buildInsertedElement(spec) {
    if (!spec || typeof spec !== 'object') return null;
    var tag = typeof spec.tag === 'string' ? spec.tag.toLowerCase() : '';
    if (ALLOWED_INSERT_TAGS.indexOf(tag) === -1) return null;
    var newPath = typeof spec.new_path === 'string' ? spec.new_path : '';
    if (!newPath) return null;

    var el = document.createElement(tag);
    el.setAttribute('data-edit', newPath);

    if (tag === 'img') {
      var attrs = spec.attrs && typeof spec.attrs === 'object' ? spec.attrs : {};
      if (!attrs.src) return null;
      for (var i = 0; i < ALLOWED_ATTR_KEYS.length; i++) {
        var key = ALLOWED_ATTR_KEYS[i];
        if (typeof attrs[key] === 'string' && attrs[key] !== '') {
          el.setAttribute(key, attrs[key]);
        }
      }
    } else if (tag === 'p' || tag === 'h2' || tag === 'h3') {
      if (typeof spec.text === 'string') el.textContent = spec.text;
    }
    return el;
  }

  function insertElementAt(reference, el, position) {
    if (!reference || !el) return false;
    if (ALLOWED_INSERT_POSITIONS.indexOf(position) === -1) return false;
    if (position === 'before') {
      if (!reference.parentNode) return false;
      reference.parentNode.insertBefore(el, reference);
      return true;
    }
    if (position === 'after') {
      if (!reference.parentNode) return false;
      reference.parentNode.insertBefore(el, reference.nextSibling);
      return true;
    }
    // inside
    var refTag = reference.tagName ? reference.tagName.toLowerCase() : '';
    if (refTag === 'img' || refTag === 'hr' || refTag === 'br' || refTag === 'input') return false;
    reference.appendChild(el);
    return true;
  }

  function setAttrs(el, attrs) {
    if (!attrs || typeof attrs !== 'object') return;
    for (var key in attrs) {
      if (!Object.prototype.hasOwnProperty.call(attrs, key)) continue;
      if (ALLOWED_ATTR_KEYS.indexOf(key) === -1) continue;
      var value = attrs[key];
      if (typeof value !== 'string') continue;
      if (value === '') {
        el.removeAttribute(key);
      } else {
        el.setAttribute(key, value);
      }
    }
  }

  // ---- Hover ----
  function onMouseOver(e) {
    if (!enabled) return;
    var target = e.target.closest('[data-edit]');
    if (target === hoveredEl) return;
    if (hoveredEl) hoveredEl.classList.remove('gp-edit-hover');
    if (target) {
      target.classList.add('gp-edit-hover');
      hoveredEl = target;
    } else {
      hoveredEl = null;
    }
  }

  function onMouseOut() {
    if (!enabled) return;
    if (hoveredEl) {
      hoveredEl.classList.remove('gp-edit-hover');
      hoveredEl = null;
    }
  }

  // ---- Click ----
  function onClick(e) {
    if (!enabled) return;
    var target = e.target.closest('[data-edit]');
    if (!target) return;
    if (target.closest('#gitpress-editor-root')) return;
    e.preventDefault();
    e.stopPropagation();

    var path = target.getAttribute('data-edit');

    // Block deselection for elements that have active AI edits.
    if (lockedPaths.has(path) && target.classList.contains('gp-edit-selected')) return;

    var isSelected = target.classList.toggle('gp-edit-selected');
    var tag = target.tagName.toLowerCase();
    var payload = {
      path: path,
      text: (target.textContent || '').trim(),
      tag: tag
    };
    // For image/link elements, also send current attribute values so the
    // panel can show a thumbnail / alt input / href input.
    if (tag === 'img') {
      payload.attrs = {
        src: target.getAttribute('src') || '',
        alt: target.getAttribute('alt') || ''
      };
    } else if (tag === 'a') {
      payload.attrs = {
        href: target.getAttribute('href') || ''
      };
    }

    if (handlers) {
      if (isSelected && handlers.onSelect) handlers.onSelect(payload);
      else if (!isSelected && handlers.onDeselect) handlers.onDeselect(payload);
    }
  }

  function bindListeners() {
    if (listenersBound) return;
    document.addEventListener('mouseover', onMouseOver);
    document.addEventListener('mouseout', onMouseOut);
    document.addEventListener('click', onClick, true);
    listenersBound = true;
  }

  App.editor = {
    init: function (cb) {
      handlers = cb || {};
      // If the page has no data-edit elements at all, warn once but still bind
      // listeners so that dynamic content added later can still be edited.
      bindListeners();
    },
    hasEditableElements: function () {
      return !!document.querySelector('[data-edit]');
    },
    setEnabled: function (value) {
      enabled = !!value;
      if (!enabled && hoveredEl) {
        hoveredEl.classList.remove('gp-edit-hover');
        hoveredEl = null;
      }
    },
    setLocked: function (value) {
      locked = !!value;
      if (!value) lockedPaths.clear();
    },
    setLockedPaths: function (paths) {
      lockedPaths.clear();
      if (Array.isArray(paths)) {
        paths.forEach(function (p) { if (p) lockedPaths.add(p); });
      }
    },
    deselect: function (path) {
      var el = findByPath(path);
      if (el) el.classList.remove('gp-edit-selected');
    },
    clearAll: function () {
      var nodes = document.querySelectorAll('.gp-edit-selected');
      for (var i = 0; i < nodes.length; i++) nodes[i].classList.remove('gp-edit-selected');
    },
    applyPreview: function (edits) {
      if (!Array.isArray(edits)) return;
      edits.forEach(function (edit) {
        if (!edit || !edit.path) return;
        var el = findByPath(edit.path);
        if (!el) return;

        // Element insertion: create a new node relative to the reference.
        // Track it separately so revert can remove it cleanly.
        if (edit.insert && typeof edit.insert === 'object') {
          var newEl = buildInsertedElement(edit.insert);
          if (newEl && insertElementAt(el, newEl, edit.insert.position)) {
            newEl.classList.add('gp-edit-preview');
            newEl.classList.add('gp-edit-inserted');
            insertedNodes.push(newEl);
          }
          return;
        }

        snapshot(el);

        // Deletion: hide the element (revert will restore from snapshot).
        if (edit.delete) {
          el.style.setProperty('display', 'none', 'important');
          el.classList.add('gp-edit-preview');
          el.classList.add('gp-edit-deleted');
          return;
        }

        if (typeof edit.text === 'string') {
          setLeadingText(el, edit.text);
        }
        if (edit.style && typeof edit.style === 'object') {
          mergeStyle(el, edit.style);
        }
        if (Array.isArray(edit.add_classes)) {
          addClasses(el, edit.add_classes);
        }
        if (Array.isArray(edit.remove_classes)) {
          removeClasses(el, edit.remove_classes);
        }
        if (edit.attrs && typeof edit.attrs === 'object') {
          setAttrs(el, edit.attrs);
        }
        el.classList.add('gp-edit-preview');
      });
    },
    revertOne: function (path) {
      if (!path) return;

      // Revert inserted nodes that reference this path.
      insertedNodes = insertedNodes.filter(function (node) {
        if (node && node.getAttribute('data-edit') &&
            node.getAttribute('data-edit').indexOf(path) === 0) {
          if (node.parentNode) node.parentNode.removeChild(node);
          return false;
        }
        return true;
      });

      // Restore from snapshot if exists.
      var snap = snapshots[path];
      if (!snap) return;
      var el = findByPath(path);
      if (!el) { delete snapshots[path]; return; }

      for (var i = el.childNodes.length - 1; i >= 0; i--) {
        var n = el.childNodes[i];
        if (n.nodeType === Node.TEXT_NODE || n.nodeType === Node.CDATA_SECTION_NODE) {
          el.removeChild(n);
        }
      }
      el.insertBefore(document.createTextNode(snap.text), el.firstChild);
      if (snap.style) el.setAttribute('style', snap.style);
      else el.removeAttribute('style');
      if (snap.className) el.setAttribute('class', snap.className);
      else el.removeAttribute('class');
      if (snap.attrs) {
        for (var k = 0; k < ALLOWED_ATTR_KEYS.length; k++) {
          var key = ALLOWED_ATTR_KEYS[k];
          if (Object.prototype.hasOwnProperty.call(snap.attrs, key)) {
            el.setAttribute(key, snap.attrs[key]);
          } else {
            el.removeAttribute(key);
          }
        }
      }
      el.classList.remove('gp-edit-preview');
      delete snapshots[path];
    },
    revertPreview: function () {
      // Remove any nodes that were added via insert edits.
      insertedNodes.forEach(function (node) {
        if (node && node.parentNode) node.parentNode.removeChild(node);
      });
      insertedNodes = [];

      Object.keys(snapshots).forEach(function (path) {
        var el = findByPath(path);
        if (!el) return;
        var snap = snapshots[path];
        // Restore leading text.
        for (var i = el.childNodes.length - 1; i >= 0; i--) {
          var n = el.childNodes[i];
          if (n.nodeType === Node.TEXT_NODE || n.nodeType === Node.CDATA_SECTION_NODE) {
            el.removeChild(n);
          }
        }
        el.insertBefore(document.createTextNode(snap.text), el.firstChild);
        if (snap.style) el.setAttribute('style', snap.style);
        else el.removeAttribute('style');
        if (snap.className) el.setAttribute('class', snap.className);
        else el.removeAttribute('class');
        // Restore whitelisted attributes.
        if (snap.attrs) {
          for (var k = 0; k < ALLOWED_ATTR_KEYS.length; k++) {
            var key = ALLOWED_ATTR_KEYS[k];
            if (Object.prototype.hasOwnProperty.call(snap.attrs, key)) {
              el.setAttribute(key, snap.attrs[key]);
            } else {
              el.removeAttribute(key);
            }
          }
        }
        el.classList.remove('gp-edit-preview');
      });
      snapshots = Object.create(null);
    }
  };
})();
