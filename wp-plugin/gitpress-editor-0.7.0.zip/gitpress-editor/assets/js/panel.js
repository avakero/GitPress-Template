/**
 * GitPress Editor — Panel UI, AI communication, REST calls.
 *
 * Attaches to window.GitPressEditorApp as .panel.
 * Exposes: mount(container), open(), close(), toggle().
 */
(function () {
  'use strict';

  var App = (window.GitPressEditorApp = window.GitPressEditorApp || {});
  var Config = window.GitPressEditor || {};
  var i18n = Config.i18n || {};

  var queue = new Map();
  // Active panel mode: 'ai' (instruction-driven) or 'insert' (add new element).
  var panelMode = 'ai';
  // Pending element insertions — key: new_path, value: { referencePath, tag, position, text, attrs }
  var insertions = new Map();
  // Staged attrs for a pending image insertion (filled by the media picker before 追加 is clicked).
  var pendingInsertImgAttrs = null;
  var lastParsedEdits = null;
  var aiInFlight = false;
  var resolvedPostId = null;
  var panelEl = null;
  var isOpen = false;

  // ---- Utilities ----
  function t(key, fallback) {
    return (i18n && i18n[key]) || fallback || key;
  }

  function escapeHtml(str) {
    var div = document.createElement('div');
    div.textContent = String(str == null ? '' : str);
    return div.innerHTML;
  }

  function cssEscape(value) {
    if (typeof window.CSS !== 'undefined' && typeof window.CSS.escape === 'function') {
      return window.CSS.escape(value);
    }
    return String(value).replace(/[^a-zA-Z0-9_-]/g, function (c) { return '\\' + c; });
  }

  function readLiveText(path) {
    try {
      var el = document.querySelector('[data-edit="' + cssEscape(path) + '"]');
      return el ? (el.textContent || '') : null;
    } catch (_) {
      return null;
    }
  }

  function showToast(message) {
    var toast = panelEl.querySelector('.gp-panel__toast');
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add('show');
    setTimeout(function () { toast.classList.remove('show'); }, 2400);
  }

  function friendlyError(status, message) {
    if (status === 429) return 'Too many requests. Please wait a moment.';
    if (status === 403) return 'Permission denied. Please re-login.';
    if (status === 401) return 'Session expired. Please reload the page.';
    if (status >= 500) return 'Server error. Please retry later.';
    return message || 'Request failed (' + status + ')';
  }

  function api(path, options) {
    options = options || {};
    options.headers = Object.assign(
      { 'Content-Type': 'application/json', 'X-WP-Nonce': Config.nonce },
      options.headers || {}
    );
    options.credentials = 'same-origin';
    return fetch(Config.restUrl.replace(/\/+$/, '') + '/' + path.replace(/^\/+/, ''), options)
      .then(function (res) {
        return res.json().then(function (body) {
          if (!res.ok) {
            var err = new Error(friendlyError(res.status, body && body.message));
            err.code = body && body.code;
            err.status = res.status;
            throw err;
          }
          return body;
        }, function () {
          var err = new Error(friendlyError(res.status, null));
          err.status = res.status;
          throw err;
        });
      }, function () {
        throw new Error('Network error. Please check your connection.');
      });
  }

  // ---- Resolve current page to post_id ----
  function resolvePostId() {
    if (resolvedPostId !== null) return Promise.resolve(resolvedPostId);
    return api('resolve?url=' + encodeURIComponent(Config.currentUrl), { method: 'GET' })
      .then(function (data) {
        resolvedPostId = data.post_id;
        return resolvedPostId;
      });
  }

  // ---- Build the panel DOM ----
  function build(container) {
    panelEl = document.createElement('div');
    panelEl.className = 'gp-panel';
    panelEl.setAttribute('role', 'dialog');
    panelEl.setAttribute('aria-label', 'GitPress Editor');
    panelEl.innerHTML = [
      '<div class="gp-panel__sheet" data-ref="sheet">',
      '  <div class="gp-panel__handle" data-ref="handle" aria-hidden="true">',
      '    <span class="gp-panel__handle-bar"></span>',
      '  </div>',
      '  <header class="gp-panel__header">',
      '    <h2 class="gp-panel__title">GitPress Editor</h2>',
      '    <button type="button" class="gp-panel__close" aria-label="' + escapeHtml(t('close', 'Close')) + '">&times;</button>',
      '  </header>',
      '  <section class="gp-panel__body">',
      '    <div class="gp-panel__queue-section">',
      '      <h3 class="gp-panel__section-title">',
      '        <span class="gp-panel__section-label">Selection</span>',
      '        <span class="gp-panel__badge" data-ref="count">0</span>',
      '      </h3>',
      '      <div class="gp-panel__empty" data-ref="empty">' + escapeHtml(t('queueEmpty', 'Tap an element on the page.')) + '</div>',
      '      <ul class="gp-panel__list" data-ref="list"></ul>',
      '    </div>',
      '    <div class="gp-panel__mode-tabs" role="tablist">',
      '      <button type="button" class="gp-panel__mode-tab is-active" data-ref="modeTabAi" data-mode="ai" role="tab" aria-selected="true">AIで編集</button>',
      '      <button type="button" class="gp-panel__mode-tab" data-ref="modeTabInsert" data-mode="insert" role="tab" aria-selected="false">要素を追加</button>',
      '    </div>',
      '    <div class="gp-panel__mode-panel" data-ref="modeAi" role="tabpanel">',
      '      <p class="gp-panel__mode-hint">選択した要素をAIに編集させます。複数選択するとまとめて指示できます。</p>',
      '      <label class="gp-panel__section-title gp-panel__visually-hidden" for="gp-instruction">' + escapeHtml(t('instruction', 'Edit instruction')) + '</label>',
      '      <textarea id="gp-instruction" data-ref="instruction" class="gp-panel__textarea" rows="3" placeholder="例: タイトルを「新しい見出し」に変えて"></textarea>',
      '      <button type="button" class="gp-btn gp-btn--ai gp-panel__instruction-send" data-ref="sendBtn" disabled>' + escapeHtml(t('sendAi', 'Send to AI')) + '</button>',
      '    </div>',
      '    <div class="gp-panel__mode-panel" data-ref="modeInsert" role="tabpanel" hidden>',
      '      <p class="gp-panel__mode-hint">選択した要素を基準に、新しい要素(画像・段落・見出し・区切り線)を追加します。</p>',
      '      <div class="gp-panel__insert-empty" data-ref="insertEmpty">まず基準にする要素をページ上でタップしてください。</div>',
      '      <div class="gp-panel__insert-form" data-ref="insertForm">',
      '        <label class="gp-panel__insert-field">基準の要素',
      '          <select class="gp-panel__insert-select" data-ref="insertRef"></select>',
      '        </label>',
      '        <div class="gp-panel__insert-row">',
      '          <label class="gp-panel__insert-field">種類',
      '            <select class="gp-panel__insert-select" data-ref="insertTag">',
      '              <option value="img">画像</option>',
      '              <option value="p">段落</option>',
      '              <option value="h2">見出し H2</option>',
      '              <option value="h3">見出し H3</option>',
      '              <option value="hr">区切り線</option>',
      '            </select>',
      '          </label>',
      '          <label class="gp-panel__insert-field">位置',
      '            <select class="gp-panel__insert-select" data-ref="insertPosition">',
      '              <option value="after">後に</option>',
      '              <option value="before">前に</option>',
      '              <option value="inside">中(末尾)に</option>',
      '            </select>',
      '          </label>',
      '        </div>',
      '        <div class="gp-panel__insert-content" data-ref="insertContent"></div>',
      '        <button type="button" class="gp-btn gp-btn--ai gp-panel__insert-add" data-ref="insertAddBtn">追加する</button>',
      '      </div>',
      '    </div>',
      '    <div class="gp-panel__ai-section" data-ref="aiSection" hidden>',
      '      <div class="gp-panel__loading" data-ref="loading" hidden>',
      '        <div class="gp-panel__spinner"></div>',
      '        <span>' + escapeHtml(t('thinking', 'AI is thinking...')) + '</span>',
      '      </div>',
      '      <div class="gp-panel__ai-content" data-ref="aiContent"></div>',
      '      <div class="gp-panel__ai-actions" data-ref="aiActions" hidden>',
      '        <button type="button" class="gp-btn gp-btn--secondary gp-btn--compact" data-ref="previewBtn">' + escapeHtml(t('preview', 'Preview')) + '</button>',
      '        <button type="button" class="gp-btn gp-btn--text gp-btn--compact" data-ref="revertBtn">' + escapeHtml(t('revert', 'Revert')) + '</button>',
      '        <button type="button" class="gp-btn gp-btn--wp gp-btn--compact" data-ref="applyBtn" disabled>' + escapeHtml(t('apply', 'Apply')) + '</button>',
      '      </div>',
      '    </div>',
      '  </section>',
      '  <footer class="gp-panel__footer">',
      '    <button type="button" class="gp-btn gp-btn--text" data-ref="clearBtn">' + escapeHtml(t('clear', 'Clear')) + '</button>',
      '  </footer>',
      '  <div class="gp-panel__toast"></div>',
      '</div>'
    ].join('\n');
    container.appendChild(panelEl);
    wire();
  }

  // ---- DOM wiring ----
  var refs = {};
  function wire() {
    panelEl.querySelectorAll('[data-ref]').forEach(function (el) {
      refs[el.getAttribute('data-ref')] = el;
    });
    panelEl.querySelector('.gp-panel__close').addEventListener('click', close);
    refs.modeTabAi.addEventListener('click', function () { setMode('ai'); });
    refs.modeTabInsert.addEventListener('click', function () { setMode('insert'); });
    refs.insertTag.addEventListener('change', renderInsertContent);
    refs.insertAddBtn.addEventListener('click', onInsertAdd);
    refs.insertContent.addEventListener('click', function (e) {
      if (e.target.closest('[data-action="insert-pick-image"]')) {
        openInsertMediaPicker();
      }
    });
    refs.sendBtn.addEventListener('click', onSend);
    refs.clearBtn.addEventListener('click', onClear);
    refs.aiContent.addEventListener('click', function (e) {
      var rm = e.target.closest('[data-action="remove-insert"]');
      if (rm) {
        removeInsertion(rm.dataset.newPath);
        return;
      }
      var rmEdit = e.target.closest('[data-action="remove-edit"]');
      if (rmEdit) {
        removeEdit(rmEdit.dataset.editPath);
      }
    });
    refs.previewBtn.addEventListener('click', onPreview);
    refs.revertBtn.addEventListener('click', onRevert);
    refs.applyBtn.addEventListener('click', onApply);
    refs.list.addEventListener('click', function (e) {
      var removeBtn = e.target.closest('.gp-panel__item-remove');
      if (removeBtn) {
        var rpath = removeBtn.dataset.path;
        queue.delete(rpath);
        removeEdit(rpath);
        dropInsertionsReferencing(rpath);
        App.editor.deselect(rpath);
        render();
        return;
      }
      var deleteBtn = e.target.closest('.gp-panel__item-delete');
      if (deleteBtn) {
        onDeleteElement(deleteBtn.dataset.path);
        return;
      }
      var pickBtn = e.target.closest('.gp-panel__item-picker');
      if (pickBtn) {
        openMediaPicker(pickBtn.dataset.path);
        return;
      }
    });

    // Alt text input (delegated change event)
    refs.list.addEventListener('input', function (e) {
      var input = e.target.closest('.gp-panel__item-alt-input');
      if (!input) return;
      setAltForPath(input.dataset.path, input.value);
    });

    bindDragGesture();
    bindViewportHandler();
  }

  // ---- Swipe-down-to-close (mobile bottom-sheet only) ----
  function isMobileLayout() {
    return window.matchMedia('(max-width: 767px)').matches;
  }

  function bindDragGesture() {
    var sheet = refs.sheet;
    var handle = refs.handle;
    if (!sheet || !handle) return;

    var startY = 0;
    var currentY = 0;
    var dragging = false;

    function onStart(e) {
      if (!isMobileLayout()) return;
      var touch = e.touches ? e.touches[0] : e;
      startY = touch.clientY;
      currentY = 0;
      dragging = true;
      sheet.classList.add('gp-panel__sheet--dragging');
    }

    function onMove(e) {
      if (!dragging) return;
      var touch = e.touches ? e.touches[0] : e;
      var delta = touch.clientY - startY;
      if (delta < 0) delta = 0;
      currentY = delta;
      sheet.style.transform = 'translateY(' + delta + 'px)';
      if (e.cancelable) e.preventDefault();
    }

    function onEnd() {
      if (!dragging) return;
      dragging = false;
      sheet.classList.remove('gp-panel__sheet--dragging');
      sheet.style.transform = '';
      // Close if dragged more than 120px or more than 25% of sheet height.
      var threshold = Math.min(120, sheet.offsetHeight * 0.25);
      if (currentY > threshold) {
        close();
      }
      currentY = 0;
    }

    handle.addEventListener('touchstart', onStart, { passive: false });
    handle.addEventListener('touchmove', onMove, { passive: false });
    handle.addEventListener('touchend', onEnd);
    handle.addEventListener('touchcancel', onEnd);
  }

  // ---- Soft keyboard handling via visualViewport ----
  function bindViewportHandler() {
    if (!window.visualViewport) return;
    var vv = window.visualViewport;
    var sheet = refs.sheet;
    if (!sheet) return;

    function adjust() {
      if (!isOpen || !isMobileLayout()) {
        sheet.style.height = '';
        return;
      }
      // When the software keyboard is open, visualViewport.height shrinks.
      // Recalculate the sheet height so the footer stays visible above the keyboard.
      var offset = Math.max(0, window.innerHeight - vv.height - vv.offsetTop);
      if (offset > 100) {
        sheet.style.height = 'calc(55dvh - ' + offset + 'px)';
      } else {
        sheet.style.height = '';
      }
    }

    vv.addEventListener('resize', adjust);
    vv.addEventListener('scroll', adjust);
    // Also adjust whenever the panel opens.
    panelEl.addEventListener('transitionend', adjust);
  }

  function setMode(mode) {
    if (mode !== 'ai' && mode !== 'insert') return;
    panelMode = mode;
    refs.modeAi.hidden = mode !== 'ai';
    refs.modeInsert.hidden = mode !== 'insert';
    refs.modeTabAi.classList.toggle('is-active', mode === 'ai');
    refs.modeTabInsert.classList.toggle('is-active', mode === 'insert');
    refs.modeTabAi.setAttribute('aria-selected', mode === 'ai' ? 'true' : 'false');
    refs.modeTabInsert.setAttribute('aria-selected', mode === 'insert' ? 'true' : 'false');
    if (mode === 'insert') {
      refreshInsertRefOptions();
      if (!refs.insertContent.childNodes.length) renderInsertContent();
    }
  }

  function render() {
    var count = queue.size;
    refs.count.textContent = count;
    refs.sendBtn.disabled = count === 0 || aiInFlight;
    refs.empty.style.display = count === 0 ? 'block' : 'none';
    refs.insertEmpty.hidden = count !== 0;
    refs.insertForm.hidden = count === 0;
    if (count > 0) {
      refreshInsertRefOptions();
      if (!refs.insertContent.childNodes.length) renderInsertContent();
    }
    refs.list.innerHTML = '';
    // Build a set of paths with active AI edits (their × should be hidden).
    var lockedEditPaths = new Set();
    if (Array.isArray(lastParsedEdits)) {
      lastParsedEdits.forEach(function (e) { if (e && e.path) lockedEditPaths.add(e.path); });
    }
    queue.forEach(function (data, path) {
      var li = document.createElement('li');
      li.className = 'gp-panel__item';
      var isLocked = lockedEditPaths.has(path);
      if (data.tag === 'img') {
        li.classList.add('gp-panel__item--img');
        var currentSrc = (data.pendingAttrs && data.pendingAttrs.src) ||
                         (data.originalAttrs && data.originalAttrs.src) || '';
        var currentAlt = (data.pendingAttrs && typeof data.pendingAttrs.alt === 'string' ? data.pendingAttrs.alt : null);
        if (currentAlt === null) currentAlt = (data.originalAttrs && data.originalAttrs.alt) || '';
        var thumbHtml = currentSrc
          ? '<img class="gp-panel__item-thumb" src="' + escapeHtml(currentSrc) + '" alt="">'
          : '<div class="gp-panel__item-thumb gp-panel__item-thumb--empty">&#x1F5BC;</div>';
        li.innerHTML =
          '<div class="gp-panel__item-img-row">' +
          thumbHtml +
          '  <div class="gp-panel__item-info">' +
          '    <div class="gp-panel__item-meta">&lt;img&gt;</div>' +
          '    <button type="button" class="gp-panel__item-picker" data-action="pick" data-path="' + escapeHtml(path) + '">画像を変更...</button>' +
          '  </div>' +
          (isLocked ? '' :
            '  <button type="button" class="gp-panel__item-delete" data-path="' + escapeHtml(path) + '" title="削除">&#x1F5D1;</button>' +
            '  <button type="button" class="gp-panel__item-remove" data-path="' + escapeHtml(path) + '">&times;</button>') +
          '</div>' +
          '<label class="gp-panel__item-alt-label">Alt テキスト' +
          '  <input type="text" class="gp-panel__item-alt-input" data-action="alt" data-path="' + escapeHtml(path) + '" value="' + escapeHtml(currentAlt) + '" placeholder="画像の説明">' +
          '</label>';
      } else {
        var liveText = readLiveText(path);
        if (liveText == null) liveText = data.text || '';
        var preview = String(liveText).replace(/\s+/g, ' ').trim().substring(0, 60);
        li.innerHTML =
          '<div class="gp-panel__item-info">' +
          '  <div class="gp-panel__item-preview">' + escapeHtml(preview || '(empty)') + '</div>' +
          '  <div class="gp-panel__item-meta">&lt;' + escapeHtml(data.tag) + '&gt;</div>' +
          '</div>' +
          (isLocked ? '' :
            '<button type="button" class="gp-panel__item-delete" data-path="' + escapeHtml(path) + '" title="削除">&#x1F5D1;</button>' +
            '<button type="button" class="gp-panel__item-remove" data-path="' + escapeHtml(path) + '">&times;</button>');
      }
      refs.list.appendChild(li);
    });
  }

  // ---- Queue callbacks from editor module ----
  function onSelect(payload) {
    queue.set(payload.path, {
      text: payload.text || '',
      tag: payload.tag,
      originalAttrs: payload.attrs || null, // initial src/alt/href captured on click
      pendingAttrs: null                    // filled in when user picks a new image / edits alt
    });
    render();
    open();
  }

  function onDeselect(payload) {
    queue.delete(payload.path);
    // Remove any pending direct edit for this path.
    removeDirectEdit(payload.path);
    // Drop any pending insertions that reference this path.
    dropInsertionsReferencing(payload.path);
    render();
  }

  function dropInsertionsReferencing(refPath) {
    var changed = false;
    insertions.forEach(function (entry, newPath) {
      if (entry.referencePath === refPath) {
        insertions.delete(newPath);
        changed = true;
      }
    });
    if (changed) syncDirectEditsToLastParsed();
  }

  // ---- Direct edits (image picker, alt input) ----
  // These are manual edits the user made outside of the AI flow.
  // They're merged into lastParsedEdits so the Preview/Apply buttons work.
  function setDirectEdit(path, attrs) {
    var data = queue.get(path);
    if (!data) return;
    data.pendingAttrs = attrs && Object.keys(attrs).length ? attrs : null;
    syncDirectEditsToLastParsed();
    // Auto-preview the attribute change on the page.
    if (data.pendingAttrs && Array.isArray(lastParsedEdits)) {
      var attrEdits = lastParsedEdits.filter(function (e) { return e && e.attrs; });
      if (attrEdits.length > 0) {
        App.editor.applyPreview(attrEdits);
      }
    }
    render();
  }

  function removeDirectEdit(path) {
    if (!Array.isArray(lastParsedEdits)) return;
    lastParsedEdits = lastParsedEdits.filter(function (e) { return !e || e.path !== path; });
    if (lastParsedEdits.length === 0) lastParsedEdits = null;
    updateAiSectionFromLastParsed();
  }

  function syncDirectEditsToLastParsed() {
    // Collect pending direct edits from queue and merge them as the source
    // of truth when the AI has not been used yet. If the AI has already
    // produced edits, we append/replace by path.
    var direct = [];
    queue.forEach(function (data, path) {
      if (data.pendingAttrs) {
        direct.push({ path: path, attrs: data.pendingAttrs });
      }
    });
    insertions.forEach(function (entry) {
      direct.push({ path: entry.referencePath, insert: entry.spec });
    });

    if (!Array.isArray(lastParsedEdits)) {
      lastParsedEdits = direct.length ? direct : null;
    } else {
      // Strip previous direct-edit entries (attrs/insert) and append the fresh set.
      // AI-generated entries (text/style/classes without attrs or insert) are preserved.
      var kept = lastParsedEdits.filter(function (e) {
        if (!e) return false;
        return !e.attrs && !e.insert;
      });
      lastParsedEdits = kept.concat(direct);
      if (lastParsedEdits.length === 0) lastParsedEdits = null;
    }
    updateAiSectionFromLastParsed();
  }

  function updateAiSectionFromLastParsed() {
    if (!lastParsedEdits || lastParsedEdits.length === 0) {
      refs.aiSection.hidden = true;
      refs.aiContent.innerHTML = '';
      refs.aiActions.hidden = true;
      refs.applyBtn.disabled = true;
      App.editor.setLocked(false);
      return;
    }
    refs.aiSection.hidden = false;
    refs.loading.hidden = true;
    refs.aiContent.classList.remove('gp-panel__ai-content--error');
    renderEditCards(lastParsedEdits);
    refs.aiActions.hidden = false;
    refs.applyBtn.disabled = false;
    App.editor.setLocked(true);
    // Lock only paths that have active AI edits — new selections stay unlocked.
    var editPaths = lastParsedEdits.map(function (e) { return e && e.path; }).filter(Boolean);
    App.editor.setLockedPaths(editPaths);
  }

  // ---- Element insertion form ----
  function refreshInsertRefOptions() {
    var sel = refs.insertRef;
    if (!sel) return;
    var prev = sel.value;
    sel.innerHTML = '';
    queue.forEach(function (data, path) {
      var opt = document.createElement('option');
      opt.value = path;
      var label = '<' + data.tag + '> ' + (String(data.text || '').trim().substring(0, 30) || path);
      opt.textContent = label;
      sel.appendChild(opt);
    });
    if (prev && sel.querySelector('option[value="' + cssAttrEscape(prev) + '"]')) {
      sel.value = prev;
    }
  }

  function cssAttrEscape(s) {
    return String(s).replace(/"/g, '\\"');
  }

  function renderInsertContent() {
    var tag = refs.insertTag.value;
    var host = refs.insertContent;
    host.innerHTML = '';
    pendingInsertImgAttrs = null;
    if (tag === 'img') {
      host.innerHTML =
        '<div class="gp-panel__insert-img" data-ref="insertImgPreview">' +
        '  <button type="button" class="gp-panel__item-picker" data-action="insert-pick-image">画像を選択...</button>' +
        '</div>';
    } else if (tag === 'p' || tag === 'h2' || tag === 'h3') {
      host.innerHTML =
        '<label class="gp-panel__insert-field">テキスト' +
        '  <input type="text" class="gp-panel__insert-text" data-ref="insertText" placeholder="挿入するテキスト">' +
        '</label>';
    }
    // hr: no extra fields
  }

  function withHiddenPanel(frame) {
    // Hide the panel sheet so it doesn't cover the WordPress media modal.
    panelEl.classList.add('gp-panel--picker-open');
    var restore = function () { panelEl.classList.remove('gp-panel--picker-open'); };
    frame.on('close', restore);
    frame.on('escape', restore);
  }

  function openInsertMediaPicker() {
    if (typeof window.wp === 'undefined' || !window.wp.media) {
      showToast('WordPress media library is not available.');
      return;
    }
    var frame = window.wp.media({
      title: 'Select an image',
      button: { text: 'Use this image' },
      library: { type: 'image' },
      multiple: false
    });
    withHiddenPanel(frame);
    frame.on('select', function () {
      var attachment = frame.state().get('selection').first().toJSON();
      var attrs = { src: attachment.url || '', alt: attachment.alt || '' };
      if (attachment.width) attrs.width = String(attachment.width);
      if (attachment.height) attrs.height = String(attachment.height);
      pendingInsertImgAttrs = attrs;
      var host = refs.insertContent;
      host.innerHTML =
        '<div class="gp-panel__insert-img">' +
        '  <img class="gp-panel__item-thumb" src="' + escapeHtml(attrs.src) + '" alt="">' +
        '  <button type="button" class="gp-panel__item-picker" data-action="insert-pick-image">画像を変更...</button>' +
        '</div>';
      showToast('画像を選択しました');
    });
    frame.open();
  }

  function genInsertId() {
    var chars = '0123456789abcdef';
    var out = '';
    for (var i = 0; i < 8; i++) out += chars[Math.floor(Math.random() * 16)];
    return out;
  }

  function onInsertAdd() {
    var refPath = refs.insertRef.value;
    var tag = refs.insertTag.value;
    var position = refs.insertPosition.value;
    if (!refPath || !queue.has(refPath)) {
      showToast('参照要素を選択してください');
      return;
    }
    var spec = {
      tag: tag,
      position: position,
      new_path: refPath + '.ins-' + genInsertId()
    };
    if (tag === 'img') {
      if (!pendingInsertImgAttrs || !pendingInsertImgAttrs.src) {
        showToast('画像を選択してください');
        return;
      }
      spec.attrs = pendingInsertImgAttrs;
    } else if (tag === 'p' || tag === 'h2' || tag === 'h3') {
      var input = refs.insertContent.querySelector('[data-ref="insertText"]');
      var text = input ? String(input.value || '').trim() : '';
      if (!text) {
        showToast('テキストを入力してください');
        return;
      }
      spec.text = text;
    }
    insertions.set(spec.new_path, { referencePath: refPath, spec: spec });
    pendingInsertImgAttrs = null;
    renderInsertContent();
    syncDirectEditsToLastParsed();
    // Auto-preview the insertion so it appears immediately on the page.
    if (Array.isArray(lastParsedEdits)) {
      var insertEdits = lastParsedEdits.filter(function (e) { return e && e.insert; });
      if (insertEdits.length > 0) {
        App.editor.applyPreview(insertEdits);
      }
    }
    render();
    showToast('挿入を追加しました');
  }

  function onDeleteElement(path) {
    if (!path || !queue.has(path)) return;
    var deleteEdit = { path: path, delete: true };
    if (!Array.isArray(lastParsedEdits)) {
      lastParsedEdits = [deleteEdit];
    } else {
      // Replace any existing edit for this path, or add new.
      var replaced = false;
      lastParsedEdits = lastParsedEdits.map(function (e) {
        if (e && e.path === path) { replaced = true; return deleteEdit; }
        return e;
      });
      if (!replaced) lastParsedEdits.push(deleteEdit);
    }
    // Auto-preview: hide the element.
    App.editor.applyPreview([deleteEdit]);
    updateAiSectionFromLastParsed();
    render();
    showToast('削除をプレビュー中');
  }

  function removeInsertion(newPath) {
    insertions.delete(newPath);
    syncDirectEditsToLastParsed();
  }

  function removeEdit(editPath) {
    if (!editPath || !Array.isArray(lastParsedEdits)) return;
    // Revert the single element's preview on the page.
    App.editor.revertOne(editPath);
    // Remove the edit from the parsed list.
    lastParsedEdits = lastParsedEdits.filter(function (e) {
      return e && e.path !== editPath;
    });
    if (lastParsedEdits.length === 0) lastParsedEdits = null;
    updateAiSectionFromLastParsed();
    render();
  }

  // ---- WordPress Media picker integration ----
  function openMediaPicker(path) {
    if (typeof window.wp === 'undefined' || !window.wp.media) {
      showToast('WordPress media library is not available.');
      return;
    }
    var frame = window.wp.media({
      title: 'Select an image',
      button: { text: 'Use this image' },
      library: { type: 'image' },
      multiple: false
    });
    withHiddenPanel(frame);
    frame.on('select', function () {
      var attachment = frame.state().get('selection').first().toJSON();
      var attrs = {
        src: attachment.url || '',
        alt: attachment.alt || ''
      };
      if (attachment.width) attrs.width = String(attachment.width);
      if (attachment.height) attrs.height = String(attachment.height);
      setDirectEdit(path, attrs);
      render();
      showToast('画像を選択しました');
    });
    frame.open();
  }

  function setAltForPath(path, alt) {
    var data = queue.get(path);
    if (!data) return;
    var current = data.pendingAttrs || {};
    // Only alt is being changed — preserve other pending attrs if any.
    current.alt = alt;
    // If no other changes and alt matches original, treat as "no change".
    if ((!current.src || current.src === (data.originalAttrs && data.originalAttrs.src)) &&
        alt === (data.originalAttrs && data.originalAttrs.alt || '')) {
      data.pendingAttrs = null;
    } else {
      data.pendingAttrs = current;
    }
    syncDirectEditsToLastParsed();
  }

  // Paths that already have an active AI edit. We use this to decide whether
  // a send should target new elements only (skip locked) or refine the
  // existing ones (include all).
  function getLockedEditPaths() {
    var locked = new Set();
    if (Array.isArray(lastParsedEdits)) {
      lastParsedEdits.forEach(function (e) {
        if (e && e.path) locked.add(e.path);
      });
    }
    return locked;
  }

  // When the queue mixes locked and unlocked items, the user is adding a
  // new element to edit — send only the unlocked ones so preview on
  // locked ones survives. When every queued item is locked, the user is
  // refining the existing edit — send everything.
  function hasAnyUnlocked() {
    var locked = getLockedEditPaths();
    var found = false;
    queue.forEach(function (_data, path) {
      if (!locked.has(path)) found = true;
    });
    return found;
  }

  // ---- Build payload for AI (v0.2.0 structured format) ----
  function buildPayload() {
    var locked = getLockedEditPaths();
    var skipLocked = hasAnyUnlocked();
    var edits = [];
    queue.forEach(function (data, path) {
      if (skipLocked && locked.has(path)) return;
      edits.push({
        path: path,
        tag: data.tag,
        text: (data.text || '').trim()
      });
    });
    return {
      edits: edits,
      instruction: refs.instruction.value.trim()
    };
  }

  // ---- AI send ----
  function onSend() {
    if (aiInFlight) return;
    var payload = buildPayload();
    if (payload.edits.length === 0) {
      showToast('AIに送る要素がありません');
      return;
    }

    // Preserve existing edits for paths that are NOT being re-sent,
    // so they survive the reset and get merged with the new AI response.
    // Paths that ARE being re-sent need their previous preview reverted
    // when the new response arrives, so the DOM state matches the new edit.
    var sendingPaths = new Set();
    payload.edits.forEach(function (e) { sendingPaths.add(e.path); });
    var preservedEdits = [];
    var replacingPaths = [];
    if (Array.isArray(lastParsedEdits)) {
      lastParsedEdits.forEach(function (edit) {
        if (!edit || !edit.path) return;
        if (sendingPaths.has(edit.path)) {
          if (replacingPaths.indexOf(edit.path) === -1) replacingPaths.push(edit.path);
        } else {
          preservedEdits.push(edit);
        }
      });
    }

    refs.aiSection.hidden = false;
    refs.loading.hidden = false;
    refs.aiContent.innerHTML = '';
    refs.aiContent.classList.remove('gp-panel__ai-content--error');
    refs.aiActions.hidden = true;
    lastParsedEdits = null;
    refs.applyBtn.disabled = true;
    aiInFlight = true;
    render();

    // Guarantee cleanup runs even if any handler throws.
    var cleanup = function () {
      try {
        refs.loading.hidden = true;
      } catch (e) {}
      aiInFlight = false;
      try { render(); } catch (e) {
        if (window.console) console.error('[GitPress Editor] render after AI send failed', e);
      }
    };

    api('ai-edit', { method: 'POST', body: JSON.stringify(payload) })
      .then(
        function (data) {
          try {
            var text = data && data.text ? data.text : '';
            var parsed = tryParseJson(text);
            if (parsed && Array.isArray(parsed.edits)) {
              // Revert previous previews for paths that are being re-edited
              // so the new edit replaces them cleanly (no class stacking).
              replacingPaths.forEach(function (p) { App.editor.revertOne(p); });
              // Merge preserved edits (from previous AI requests) with new ones.
              lastParsedEdits = preservedEdits.concat(parsed.edits);
              renderEditCards(lastParsedEdits);
              // Auto-apply preview so changes appear immediately (hot-reload UX).
              App.editor.applyPreview(parsed.edits);
              App.editor.setLocked(true);
              // Lock only paths with active edits — new selections stay unlocked.
              var editPaths = lastParsedEdits.map(function (e) { return e && e.path; }).filter(Boolean);
              App.editor.setLockedPaths(editPaths);
              refs.aiActions.hidden = false;
              refs.applyBtn.disabled = false;
            } else {
              refs.aiContent.textContent = text;
            }
          } catch (inner) {
            if (window.console) console.error('[GitPress Editor] AI response handler threw', inner);
            refs.aiContent.textContent = 'AIレスポンスの処理中にエラーが発生しました: ' + (inner && inner.message || inner);
            refs.aiContent.classList.add('gp-panel__ai-content--error');
          }
        },
        function (err) {
          try {
            refs.aiContent.textContent = (err && err.message) || 'Error';
            refs.aiContent.classList.add('gp-panel__ai-content--error');
          } catch (e) {}
        }
      )
      .then(cleanup, cleanup);
  }

  function tryParseJson(text) {
    var fenceMatch = text.match(/```(?:json)?\s*([\s\S]*?)```/);
    var jsonStr = fenceMatch ? fenceMatch[1] : text;
    try {
      return JSON.parse(jsonStr);
    } catch (_) {
      return null;
    }
  }

  function renderEditCards(edits) {
    refs.aiContent.innerHTML = '';
    edits.forEach(function (edit) {
      var card = document.createElement('div');
      card.className = 'gp-panel__card';
      if (edit.insert) card.classList.add('gp-panel__card--insert');
      if (edit.delete) card.classList.add('gp-panel__card--delete');

      var html = '<div class="gp-panel__card-path">';
      if (edit.delete) {
        html += '🗑 削除 → ' + escapeHtml(edit.path || '');
        html += ' <button type="button" class="gp-panel__card-remove" data-action="remove-edit" data-edit-path="' +
                escapeHtml(edit.path || '') + '" aria-label="この編集を取り消す">&times;</button>';
      } else if (edit.insert) {
        html += '挿入 &rarr; ' + escapeHtml(edit.insert.position || '') + ' ' + escapeHtml(edit.path || '');
        html += ' <button type="button" class="gp-panel__card-remove" data-action="remove-insert" data-new-path="' +
                escapeHtml(edit.insert.new_path || '') + '" aria-label="削除">&times;</button>';
      } else {
        html += escapeHtml(edit.path || '');
        html += ' <button type="button" class="gp-panel__card-remove" data-action="remove-edit" data-edit-path="' +
                escapeHtml(edit.path || '') + '" aria-label="この編集を取り消す">&times;</button>';
      }
      html += '</div>';

      if (edit.insert) {
        var ins = edit.insert;
        html += '<div class="gp-panel__card-insert">&lt;' + escapeHtml(ins.tag) + '&gt;';
        if (ins.tag === 'img' && ins.attrs && ins.attrs.src) {
          html += '<img class="gp-panel__card-attr-thumb" src="' + escapeHtml(ins.attrs.src) + '" alt="">';
        } else if (typeof ins.text === 'string' && ins.text) {
          html += ' ' + escapeHtml(ins.text);
        }
        html += '</div>';
      }

      // Text change
      if (typeof edit.text === 'string') {
        html += '<div class="gp-panel__card-diff">' +
                '  <span class="gp-panel__card-ins">' + escapeHtml(edit.text) + '</span>' +
                '</div>';
      }

      // Style change
      if (edit.style && typeof edit.style === 'object') {
        var styleRows = '';
        Object.keys(edit.style).forEach(function (prop) {
          styleRows += '<div>' + escapeHtml(prop) + ': ' + escapeHtml(String(edit.style[prop])) + '</div>';
        });
        if (styleRows) {
          html += '<div class="gp-panel__card-style">' + styleRows + '</div>';
        }
      }

      // Class changes
      var classesParts = [];
      if (Array.isArray(edit.add_classes) && edit.add_classes.length) {
        classesParts.push('+ ' + edit.add_classes.join(' +'));
      }
      if (Array.isArray(edit.remove_classes) && edit.remove_classes.length) {
        classesParts.push('- ' + edit.remove_classes.join(' -'));
      }
      if (classesParts.length) {
        html += '<div class="gp-panel__card-classes">' + escapeHtml(classesParts.join('  ')) + '</div>';
      }

      // Attribute changes (image swap, alt update, href change, ...)
      if (edit.attrs && typeof edit.attrs === 'object') {
        var attrsHtml = '';
        if (edit.attrs.src) {
          attrsHtml += '<img class="gp-panel__card-attr-thumb" src="' + escapeHtml(edit.attrs.src) + '" alt="">';
        }
        Object.keys(edit.attrs).forEach(function (k) {
          if (k === 'src') return;
          attrsHtml += '<div>' + escapeHtml(k) + ': ' + escapeHtml(String(edit.attrs[k])) + '</div>';
        });
        if (attrsHtml) {
          html += '<div class="gp-panel__card-attrs">' + attrsHtml + '</div>';
        }
      }

      if (edit.reason) {
        html += '<div class="gp-panel__card-reason">' + escapeHtml(edit.reason) + '</div>';
      }

      card.innerHTML = html;
      refs.aiContent.appendChild(card);
    });
  }

  // ---- Preview / Revert / Clear ----
  function onPreview() {
    if (!lastParsedEdits) return;
    App.editor.applyPreview(lastParsedEdits);
    render();
    showToast(t('preview', 'Preview'));
  }

  function onRevert() {
    App.editor.revertPreview();
    showToast(t('revert', 'Revert'));
    // Reload page to ensure clean state after reverting AI edits.
    setTimeout(function () { window.location.reload(); }, 600);
  }

  function onClear() {
    queue.clear();
    insertions.clear();
    pendingInsertImgAttrs = null;
    refs.instruction.value = '';
    refs.aiSection.hidden = true;
    refs.aiContent.innerHTML = '';
    refs.aiActions.hidden = true;
    var hadEdits = !!lastParsedEdits;
    lastParsedEdits = null;
    App.editor.setLocked(false);
    App.editor.revertPreview();
    App.editor.clearAll();
    render();
    // Reload page to reset to a clean state if AI edits were present.
    if (hadEdits) {
      setTimeout(function () { window.location.reload(); }, 400);
    }
  }

  // ---- Apply to WordPress ----
  function onApply() {
    if (!lastParsedEdits || refs.applyBtn.disabled) return;
    var confirmMsg = t('confirmApply', 'Apply edits to WordPress? The live site will be updated.');
    if (!window.confirm(confirmMsg)) return;

    refs.applyBtn.disabled = true;
    var origLabel = refs.applyBtn.textContent;
    refs.applyBtn.textContent = '...';

    var cleanup = function () {
      try {
        refs.applyBtn.textContent = origLabel;
        refs.applyBtn.disabled = false;
      } catch (e) {}
    };

    resolvePostId()
      .then(function (postId) {
        return api('apply', {
          method: 'POST',
          body: JSON.stringify({ post_id: postId, edits: lastParsedEdits })
        });
      })
      .then(
        function (data) {
          try {
            showToast(t('applied', 'Applied.') + ' (' + (data && data.applied) + ')');
          } catch (e) {}
          // Reload page to show the saved content cleanly.
          setTimeout(function () { window.location.reload(); }, 1000);
        },
        function (err) {
          try {
            showToast((err && err.message) || 'Error');
          } catch (e) {}
          cleanup();
        }
      );
  }

  // ---- Open / Close ----
  function open() {
    if (!panelEl || isOpen) return;
    panelEl.classList.add('gp-panel--open');
    // Push the page body to the left so the panel doesn't cover content.
    if (document.body) document.body.classList.add('gp-panel-open');
    isOpen = true;
  }
  function close() {
    if (!panelEl || !isOpen) return;
    panelEl.classList.remove('gp-panel--open');
    if (document.body) document.body.classList.remove('gp-panel-open');
    isOpen = false;
  }
  function toggle() { isOpen ? close() : open(); }

  App.panel = {
    mount: function (container) {
      build(container);
      render();
      App.editor.init({ onSelect: onSelect, onDeselect: onDeselect });
    },
    open: open,
    close: close,
    toggle: toggle
  };
})();
