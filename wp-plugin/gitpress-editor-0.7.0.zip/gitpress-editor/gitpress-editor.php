<?php
/**
 * Plugin Name:       GitPress Editor
 * Plugin URI:        https://github.com/avakero/GitPress
 * Description:       Visual AI-powered editor for WordPress. Click elements on any page and edit them with Google Gemini.
 * Version:           0.7.0
 * Requires at least: 5.6
 * Requires PHP:      7.4
 * Author:            avakero
 * License:           MIT
 * Text Domain:       gitpress-editor
 * Domain Path:       /languages
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'GITPRESS_EDITOR_VERSION', '0.7.0' );
define( 'GITPRESS_EDITOR_FILE', __FILE__ );
define( 'GITPRESS_EDITOR_DIR', plugin_dir_path( __FILE__ ) );
define( 'GITPRESS_EDITOR_URL', plugin_dir_url( __FILE__ ) );
define( 'GITPRESS_EDITOR_BASENAME', plugin_basename( __FILE__ ) );

/**
 * Trial API key embedded for hybrid strategy.
 * This is intentionally low-quota and will be replaced by a proxy server in the future.
 * Clients who need more can enter their own key in the settings screen.
 *
 * SECURITY NOTE: This value is visible in the plugin source. It is expected to be
 * rotated periodically and rate-limited at the Google AI Studio side.
 */
if ( ! defined( 'GITPRESS_EDITOR_TRIAL_KEY' ) ) {
	define( 'GITPRESS_EDITOR_TRIAL_KEY', '' );
}

// Autoloader (PSR-like, flat structure).
spl_autoload_register(
	function ( $class ) {
		if ( strpos( $class, 'GitPress_Editor_' ) !== 0 ) {
			return;
		}
		$slug = strtolower( str_replace( array( 'GitPress_Editor_', '_' ), array( '', '-' ), $class ) );
		$file = GITPRESS_EDITOR_DIR . 'includes/class-' . $slug . '.php';
		if ( file_exists( $file ) ) {
			require_once $file;
		}
	}
);

/**
 * Bootstrap plugin on plugins_loaded so that translations are ready.
 */
add_action(
	'plugins_loaded',
	function () {
		load_plugin_textdomain( 'gitpress-editor', false, dirname( GITPRESS_EDITOR_BASENAME ) . '/languages' );
		GitPress_Editor_Plugin::instance()->init();
	}
);

/**
 * Activation: set default options.
 */
register_activation_hook(
	__FILE__,
	function () {
		$defaults = array(
			'model'          => 'gemini-2.0-flash',
			'enabled_roles'  => array( 'administrator', 'editor' ),
			'show_button'    => '1',
			'use_trial_key'  => '1',
			'user_api_key'   => '',
		);
		if ( false === get_option( 'gitpress_editor_options' ) ) {
			add_option( 'gitpress_editor_options', $defaults );
		}
	}
);
