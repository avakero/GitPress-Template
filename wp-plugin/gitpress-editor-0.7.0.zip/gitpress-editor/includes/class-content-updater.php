<?php
/**
 * Content updater.
 *
 * Applies structured edits (text / style / add_classes / remove_classes)
 * to elements identified by `data-edit` attributes within a post's
 * `post_content`. Uses DOMDocument for safe, surgical updates — no
 * string-based replacement, no HTML injection from AI output.
 *
 * @package GitPress_Editor
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class GitPress_Editor_Content_Updater {

	/**
	 * Maximum allowed final post_content size (bytes).
	 */
	const MAX_CONTENT_BYTES = 4194304; // 4 MiB

	/**
	 * Apply a list of structured edits to a post.
	 *
	 * Each edit is an associative array with these optional keys:
	 *   - path          (string, required) : data-edit value identifying the element
	 *   - text          (string)           : replacement text content
	 *   - style         (array)            : CSS property => value map
	 *   - add_classes   (array)            : class names to add
	 *   - remove_classes (array)           : class names to remove
	 *
	 * @param int   $post_id Target post.
	 * @param array $edits   Edits to apply.
	 * @return array|WP_Error {
	 *     @type int $applied Number of successful element updates.
	 *     @type int $skipped Number of edits that couldn't be applied.
	 * }
	 */
	public static function apply( $post_id, $edits ) {
		$post = get_post( $post_id );
		if ( ! $post ) {
			return new WP_Error(
				'gitpress_editor_post_not_found',
				__( 'Post not found.', 'gitpress-editor' ),
				array( 'status' => 404 )
			);
		}

		if ( ! is_array( $edits ) || empty( $edits ) ) {
			return new WP_Error(
				'gitpress_editor_empty_edits',
				__( 'No edits supplied.', 'gitpress-editor' ),
				array( 'status' => 400 )
			);
		}

		$original = $post->post_content;
		$dom      = self::load_dom( $original );
		if ( null === $dom ) {
			return new WP_Error(
				'gitpress_editor_dom_parse_failed',
				__( 'Could not parse the post content.', 'gitpress-editor' ),
				array( 'status' => 500 )
			);
		}

		$xpath   = new DOMXPath( $dom );
		$applied = 0;
		$skipped = 0;

		foreach ( $edits as $edit ) {
			if ( empty( $edit['path'] ) ) {
				$skipped++;
				continue;
			}
			$path  = (string) $edit['path'];
			$nodes = $xpath->query( '//*[@data-edit="' . self::xpath_escape( $path ) . '"]' );
			if ( ! $nodes || 0 === $nodes->length ) {
				$skipped++;
				continue;
			}
			// data-edit values are unique per page by convention, use the first match.
			$node = $nodes->item( 0 );

			$touched = false;

			// 1. Text content replacement
			if ( isset( $edit['text'] ) && is_string( $edit['text'] ) ) {
				self::set_text( $node, $edit['text'] );
				$touched = true;
			}

			// 2. Inline style merge
			if ( isset( $edit['style'] ) && is_array( $edit['style'] ) && ! empty( $edit['style'] ) ) {
				self::merge_style( $node, $edit['style'] );
				$touched = true;
			}

			// 3. Class additions
			if ( isset( $edit['add_classes'] ) && is_array( $edit['add_classes'] ) && ! empty( $edit['add_classes'] ) ) {
				self::add_classes( $node, $edit['add_classes'] );
				$touched = true;
			}

			// 4. Class removals
			if ( isset( $edit['remove_classes'] ) && is_array( $edit['remove_classes'] ) && ! empty( $edit['remove_classes'] ) ) {
				self::remove_classes( $node, $edit['remove_classes'] );
				$touched = true;
			}

			// 5. Generic attributes (src / alt / href / srcset / sizes / width / height)
			// Used for image and link updates from the media picker.
			if ( isset( $edit['attrs'] ) && is_array( $edit['attrs'] ) && ! empty( $edit['attrs'] ) ) {
				self::set_attrs( $node, $edit['attrs'] );
				$touched = true;
			}

			// 6. Element insertion — create a new element relative to $node.
			if ( isset( $edit['insert'] ) && is_array( $edit['insert'] ) ) {
				if ( self::insert_element( $node, $edit['insert'] ) ) {
					$touched = true;
				}
			}

			// 7. Element deletion — remove the node from the DOM.
			if ( ! empty( $edit['delete'] ) ) {
				if ( $node->parentNode ) {
					$node->parentNode->removeChild( $node );
					$touched = true;
				}
			}

			if ( $touched ) {
				$applied++;
			} else {
				$skipped++;
			}
		}

		if ( 0 === $applied ) {
			return new WP_Error(
				'gitpress_editor_no_changes',
				__( 'No elements matched the supplied edits.', 'gitpress-editor' ),
				array( 'status' => 422 )
			);
		}

		$new_content = self::save_dom( $dom );
		if ( strlen( $new_content ) > self::MAX_CONTENT_BYTES ) {
			return new WP_Error(
				'gitpress_editor_content_too_large',
				__( 'Resulting content would be too large.', 'gitpress-editor' ),
				array( 'status' => 413 )
			);
		}

		// Temporarily suspend the content kses filters. Our content was
		// built via DOMDocument with a strict whitelist of styles / classes /
		// attributes, so there is nothing left to sanitize. Running kses
		// here would strip the `data-edit` attributes we rely on for
		// subsequent edits, making previously-edited elements unreachable
		// on the next page load.
		$had_kses_post  = remove_filter( 'content_save_pre', 'wp_filter_post_kses' );
		$had_kses_filt  = remove_filter( 'content_filtered_save_pre', 'wp_filter_post_kses' );

		$update = wp_update_post(
			array(
				'ID'           => $post_id,
				'post_content' => $new_content,
			),
			true
		);

		if ( $had_kses_post ) {
			add_filter( 'content_save_pre', 'wp_filter_post_kses' );
		}
		if ( $had_kses_filt ) {
			add_filter( 'content_filtered_save_pre', 'wp_filter_post_kses' );
		}

		if ( is_wp_error( $update ) ) {
			return $update;
		}

		return array(
			'applied' => $applied,
			'skipped' => $skipped,
		);
	}

	// ==================================================================
	// DOM helpers
	// ==================================================================

	/**
	 * Load a fragment of HTML into a DOMDocument.
	 *
	 * Uses a marker sentinel so we can trivially extract exactly the same
	 * fragment back out without loadHTML's auto-added <html>/<body>.
	 *
	 * @param string $html Post content (may include Gutenberg block comments).
	 * @return DOMDocument|null
	 */
	private static function load_dom( $html ) {
		$doc = new DOMDocument( '1.0', 'UTF-8' );
		$doc->preserveWhiteSpace = true;
		$doc->formatOutput       = false;

		// Wrap in a marker element so we can slice it back out cleanly.
		// Also prepend XML encoding declaration so DOMDocument treats input as UTF-8.
		$wrapped = '<?xml encoding="utf-8" ?><div id="gp-root">' . $html . '</div>';

		libxml_use_internal_errors( true );
		$loaded = $doc->loadHTML( $wrapped, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD );
		libxml_clear_errors();
		if ( ! $loaded ) {
			return null;
		}
		return $doc;
	}

	/**
	 * Serialize the DOM back to HTML, returning only the content inside the wrapper.
	 *
	 * @param DOMDocument $doc Document to serialize.
	 * @return string
	 */
	private static function save_dom( $doc ) {
		// Find the gp-root wrapper and serialize its children.
		$root = $doc->getElementById( 'gp-root' );
		if ( ! $root ) {
			// Fallback: serialize whole document.
			return trim( (string) $doc->saveHTML() );
		}
		$out = '';
		foreach ( $root->childNodes as $child ) {
			$out .= $doc->saveHTML( $child );
		}
		return $out;
	}

	/**
	 * Escape a string for safe interpolation into an XPath `"..."` literal.
	 *
	 * @param string $value Value that may contain " or '.
	 * @return string
	 */
	private static function xpath_escape( $value ) {
		// If the value contains no quotes, use double-quote form.
		if ( false === strpos( $value, '"' ) ) {
			return $value;
		}
		// If it contains no single quotes, caller should switch to single-quoted form.
		// Fallback: strip double quotes (they shouldn't appear in data-edit values anyway).
		return str_replace( '"', '', $value );
	}

	/**
	 * Replace the text content of an element, preserving attributes.
	 *
	 * For anchor-like elements we only touch the first text node to keep
	 * icons / badges inside the element intact.
	 *
	 * @param DOMNode $node Target element.
	 * @param string  $text New text.
	 */
	private static function set_text( $node, $text ) {
		// Remove existing child nodes that are text nodes.
		$to_remove = array();
		foreach ( $node->childNodes as $child ) {
			if ( $child->nodeType === XML_TEXT_NODE || $child->nodeType === XML_CDATA_SECTION_NODE ) {
				$to_remove[] = $child;
			}
		}
		foreach ( $to_remove as $child ) {
			$node->removeChild( $child );
		}
		// Prepend the new text as a single text node.
		$text_node = $node->ownerDocument->createTextNode( $text );
		if ( $node->firstChild ) {
			$node->insertBefore( $text_node, $node->firstChild );
		} else {
			$node->appendChild( $text_node );
		}
	}

	/**
	 * Parse a `style` attribute string into an associative array.
	 *
	 * @param string $style_string Raw value of `style` attribute.
	 * @return array<string,string>
	 */
	private static function parse_style( $style_string ) {
		$result = array();
		if ( ! $style_string ) {
			return $result;
		}
		$rules = explode( ';', $style_string );
		foreach ( $rules as $rule ) {
			$rule = trim( $rule );
			if ( '' === $rule ) {
				continue;
			}
			$pos = strpos( $rule, ':' );
			if ( false === $pos ) {
				continue;
			}
			$prop  = strtolower( trim( substr( $rule, 0, $pos ) ) );
			$value = trim( substr( $rule, $pos + 1 ) );
			if ( '' !== $prop && '' !== $value ) {
				$result[ $prop ] = $value;
			}
		}
		return $result;
	}

	/**
	 * Serialize an associative style array back to a `style` attribute string.
	 *
	 * @param array<string,string> $styles Style map.
	 * @return string
	 */
	private static function serialize_style( $styles ) {
		$parts = array();
		foreach ( $styles as $prop => $value ) {
			$parts[] = $prop . ': ' . $value;
		}
		return implode( '; ', $parts );
	}

	/**
	 * Merge incoming style properties into an element's existing `style`.
	 *
	 * @param DOMElement           $node   Target element.
	 * @param array<string,string> $styles New styles to apply.
	 */
	private static function merge_style( $node, $styles ) {
		$current = self::parse_style( (string) $node->getAttribute( 'style' ) );
		foreach ( $styles as $prop => $value ) {
			$prop  = strtolower( trim( (string) $prop ) );
			$value = trim( (string) $value );
			if ( '' === $prop || '' === $value ) {
				continue;
			}
			// Append !important to AI-supplied values so they override
			// theme CSS (e.g. Elementor) that may use !important.
			if ( false === stripos( $value, '!important' ) ) {
				$value .= ' !important';
			}
			$current[ $prop ] = $value;

			// When `color` is set, mirror the value onto -webkit-text-fill-color
			// and neutralize background-image / background-clip so preset
			// classes that paint text with a gradient (gp-text-rainbow and
			// friends) don't keep the text invisible. Any explicit value the
			// AI supplies for those properties later in the same style map
			// will win because array keys overwrite.
			if ( 'color' === $prop ) {
				$current['-webkit-text-fill-color'] = $value;
				if ( ! isset( $styles['background-image'] ) ) {
					$current['background-image'] = 'none !important';
				}
				if ( ! isset( $styles['background-clip'] ) ) {
					$current['background-clip'] = 'border-box !important';
				}
				if ( ! isset( $styles['-webkit-background-clip'] ) ) {
					$current['-webkit-background-clip'] = 'border-box !important';
				}
			}
		}
		$serialized = self::serialize_style( $current );
		if ( '' === $serialized ) {
			$node->removeAttribute( 'style' );
		} else {
			$node->setAttribute( 'style', $serialized );
		}
	}

	/**
	 * Add classes to an element's `class` attribute (deduplicated).
	 *
	 * @param DOMElement $node        Target element.
	 * @param string[]   $new_classes Classes to add.
	 */
	private static function add_classes( $node, $new_classes ) {
		$existing = preg_split( '/\s+/', trim( (string) $node->getAttribute( 'class' ) ) );
		$existing = array_filter( $existing );
		foreach ( $new_classes as $cls ) {
			$cls = trim( (string) $cls );
			if ( '' !== $cls && ! in_array( $cls, $existing, true ) ) {
				$existing[] = $cls;
			}
		}
		$node->setAttribute( 'class', implode( ' ', $existing ) );
	}

	/**
	 * Whitelist of HTML attributes that the REST API is allowed to change
	 * via the `attrs` field. Only used by set_attrs() as a secondary defense
	 * — the primary whitelist is enforced in class-rest-api.php.
	 *
	 * @var string[]
	 */
	private static $allowed_attr_keys = array(
		'src', 'alt', 'srcset', 'sizes', 'width', 'height',
		'href', 'title', 'target', 'rel',
	);

	/**
	 * Set a filtered map of HTML attributes on an element.
	 *
	 * Keys are lower-cased and checked against a whitelist. Values are
	 * passed through as-is (the REST layer already sanitized URLs and
	 * strings). An empty value removes the attribute.
	 *
	 * @param DOMElement           $node  Target element.
	 * @param array<string,string> $attrs Attributes map.
	 */
	private static function set_attrs( $node, $attrs ) {
		foreach ( $attrs as $key => $value ) {
			$key = strtolower( trim( (string) $key ) );
			if ( '' === $key || ! in_array( $key, self::$allowed_attr_keys, true ) ) {
				continue;
			}
			$value = (string) $value;
			if ( '' === $value ) {
				$node->removeAttribute( $key );
			} else {
				$node->setAttribute( $key, $value );
			}
		}
	}

	/**
	 * Whitelist of tags that can be inserted as new elements.
	 *
	 * @var string[]
	 */
	private static $allowed_insert_tags = array( 'img', 'p', 'h2', 'h3', 'hr' );

	/**
	 * Create a new element and insert it relative to a reference node.
	 *
	 * Spec keys:
	 *   - tag       (string, required) : one of allowed_insert_tags
	 *   - position  (string, required) : before | after | inside
	 *   - new_path  (string, required) : data-edit value for the new element
	 *   - text      (string, optional) : text content for p/h2/h3
	 *   - attrs     (array,  optional) : attributes for img (requires src)
	 *
	 * @param DOMElement $reference Reference node.
	 * @param array      $spec      Insertion spec (already sanitized).
	 * @return bool True on success.
	 */
	private static function insert_element( $reference, $spec ) {
		$tag      = isset( $spec['tag'] ) ? strtolower( (string) $spec['tag'] ) : '';
		$position = isset( $spec['position'] ) ? strtolower( (string) $spec['position'] ) : '';
		$new_path = isset( $spec['new_path'] ) ? (string) $spec['new_path'] : '';

		if ( ! in_array( $tag, self::$allowed_insert_tags, true ) ) {
			return false;
		}
		if ( ! in_array( $position, array( 'before', 'after', 'inside' ), true ) ) {
			return false;
		}
		if ( '' === $new_path ) {
			return false;
		}

		$doc = $reference->ownerDocument;
		if ( ! $doc ) {
			return false;
		}

		$el = $doc->createElement( $tag );
		$el->setAttribute( 'data-edit', $new_path );

		if ( in_array( $tag, array( 'p', 'h2', 'h3' ), true ) ) {
			$text = isset( $spec['text'] ) ? (string) $spec['text'] : '';
			if ( '' !== $text ) {
				$el->appendChild( $doc->createTextNode( $text ) );
			}
		}

		if ( 'img' === $tag && isset( $spec['attrs'] ) && is_array( $spec['attrs'] ) ) {
			self::set_attrs( $el, $spec['attrs'] );
			if ( '' === (string) $el->getAttribute( 'src' ) ) {
				return false;
			}
		}

		switch ( $position ) {
			case 'before':
				if ( ! $reference->parentNode ) {
					return false;
				}
				$reference->parentNode->insertBefore( $el, $reference );
				return true;

			case 'after':
				if ( ! $reference->parentNode ) {
					return false;
				}
				if ( $reference->nextSibling ) {
					$reference->parentNode->insertBefore( $el, $reference->nextSibling );
				} else {
					$reference->parentNode->appendChild( $el );
				}
				return true;

			case 'inside':
				$ref_tag = strtolower( $reference->tagName );
				if ( in_array( $ref_tag, array( 'img', 'hr', 'br', 'input' ), true ) ) {
					return false;
				}
				$reference->appendChild( $el );
				return true;
		}
		return false;
	}

	/**
	 * Remove classes from an element's `class` attribute.
	 *
	 * @param DOMElement $node    Target element.
	 * @param string[]   $classes Classes to remove.
	 */
	private static function remove_classes( $node, $classes ) {
		$existing = preg_split( '/\s+/', trim( (string) $node->getAttribute( 'class' ) ) );
		$existing = array_filter( $existing );
		$remove   = array_map( 'trim', $classes );
		$result   = array_values( array_diff( $existing, $remove ) );
		if ( empty( $result ) ) {
			$node->removeAttribute( 'class' );
		} else {
			$node->setAttribute( 'class', implode( ' ', $result ) );
		}
	}
}
