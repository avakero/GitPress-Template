<?php
/**
 * Frontend asset injection.
 *
 * Only logged-in users with an enabled role see the editor.
 *
 * @package GitPress_Editor
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class GitPress_Editor_Frontend {

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	public function init() {
		add_action( 'wp_enqueue_scripts', array( $this, 'maybe_enqueue' ) );
		add_action( 'wp_footer', array( $this, 'maybe_render_root' ) );
	}

	/**
	 * Enqueue frontend assets when the current user is allowed to edit.
	 */
	public function maybe_enqueue() {
		if ( is_admin() ) {
			return;
		}
		if ( ! GitPress_Editor_Security::current_user_can_edit() ) {
			return;
		}
		$options = GitPress_Editor_Plugin::get_options();
		if ( empty( $options['show_button'] ) ) {
			return;
		}

		// Load the WordPress media library JS (wp.media) so the image picker
		// in panel.js can open it. Only loaded for users who can upload files.
		if ( current_user_can( 'upload_files' ) && function_exists( 'wp_enqueue_media' ) ) {
			wp_enqueue_media();
		}

		wp_enqueue_style(
			'gitpress-editor-presets',
			GITPRESS_EDITOR_URL . 'assets/css/presets.css',
			array(),
			GITPRESS_EDITOR_VERSION
		);
		wp_enqueue_style(
			'gitpress-editor-highlight',
			GITPRESS_EDITOR_URL . 'assets/css/highlight.css',
			array(),
			GITPRESS_EDITOR_VERSION
		);
		wp_enqueue_style(
			'gitpress-editor-panel',
			GITPRESS_EDITOR_URL . 'assets/css/editor.css',
			array(),
			GITPRESS_EDITOR_VERSION
		);
		wp_enqueue_script(
			'gitpress-editor-core',
			GITPRESS_EDITOR_URL . 'assets/js/editor.js',
			array(),
			GITPRESS_EDITOR_VERSION,
			true
		);
		wp_enqueue_script(
			'gitpress-editor-panel',
			GITPRESS_EDITOR_URL . 'assets/js/panel.js',
			array( 'gitpress-editor-core' ),
			GITPRESS_EDITOR_VERSION,
			true
		);
		wp_enqueue_script(
			'gitpress-editor-bootstrap',
			GITPRESS_EDITOR_URL . 'assets/js/bootstrap.js',
			array( 'gitpress-editor-core', 'gitpress-editor-panel' ),
			GITPRESS_EDITOR_VERSION,
			true
		);

		wp_localize_script(
			'gitpress-editor-panel',
			'GitPressEditor',
			array(
				'restUrl'    => esc_url_raw( rest_url( GitPress_Editor_Security::REST_NAMESPACE . '/' ) ),
				'nonce'      => wp_create_nonce( 'wp_rest' ),
				'currentUrl' => esc_url_raw( home_url( add_query_arg( null, null ) ) ),
				'i18n'       => array(
					'launch'       => __( 'Edit', 'gitpress-editor' ),
					'queueEmpty'   => __( 'Tap an element on the page.', 'gitpress-editor' ),
					'instruction'  => __( 'Edit instruction', 'gitpress-editor' ),
					'sendAi'       => __( 'Send to AI', 'gitpress-editor' ),
					'clear'        => __( 'Clear', 'gitpress-editor' ),
					'preview'      => __( 'Preview', 'gitpress-editor' ),
					'revert'       => __( 'Revert', 'gitpress-editor' ),
					'apply'        => __( 'Apply to WordPress', 'gitpress-editor' ),
					'close'        => __( 'Close', 'gitpress-editor' ),
					'thinking'     => __( 'AI is thinking...', 'gitpress-editor' ),
					'applied'      => __( 'Applied.', 'gitpress-editor' ),
					'confirmApply' => __( 'Apply edits to WordPress? The live site will be updated.', 'gitpress-editor' ),
				),
			)
		);
	}

	/**
	 * Render the root DOM element that bootstrap.js will mount into.
	 */
	public function maybe_render_root() {
		if ( is_admin() ) {
			return;
		}
		if ( ! GitPress_Editor_Security::current_user_can_edit() ) {
			return;
		}
		$options = GitPress_Editor_Plugin::get_options();
		if ( empty( $options['show_button'] ) ) {
			return;
		}
		echo '<div id="gitpress-editor-root"></div>';
	}
}
