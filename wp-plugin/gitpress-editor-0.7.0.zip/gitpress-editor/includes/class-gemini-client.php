<?php
/**
 * Gemini API client with hybrid key selection.
 *
 * Chooses, in order of precedence:
 *   1. The user-supplied key (decrypted from options), if present.
 *   2. The bundled trial key, if enabled and non-empty.
 *
 * @package GitPress_Editor
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class GitPress_Editor_Gemini_Client {

	/**
	 * Resolve the API key to use for this request.
	 *
	 * @return string|WP_Error
	 */
	public static function get_api_key() {
		$options = GitPress_Editor_Plugin::get_options();

		if ( ! empty( $options['user_api_key'] ) ) {
			$plain = GitPress_Editor_Security::decrypt( $options['user_api_key'] );
			if ( '' !== $plain ) {
				return $plain;
			}
		}

		if ( ! empty( $options['use_trial_key'] ) && defined( 'GITPRESS_EDITOR_TRIAL_KEY' ) && '' !== GITPRESS_EDITOR_TRIAL_KEY ) {
			return GITPRESS_EDITOR_TRIAL_KEY;
		}

		return new WP_Error(
			'gitpress_editor_no_api_key',
			__( 'No Gemini API key available. Set one in Settings → GitPress Editor, or enable the trial key.', 'gitpress-editor' ),
			array( 'status' => 400 )
		);
	}

	/**
	 * Send a payload to Gemini and return the raw text response.
	 *
	 * @param array $payload The `edits` + `instruction` structure from the frontend.
	 * @return string|WP_Error
	 */
	public static function generate_edits( $payload ) {
		$key = self::get_api_key();
		if ( is_wp_error( $key ) ) {
			return $key;
		}

		$options = GitPress_Editor_Plugin::get_options();
		$model   = isset( $options['model'] ) ? $options['model'] : 'gemini-2.0-flash';
		$url     = sprintf( 'https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent?key=%s', $model, rawurlencode( $key ) );

		$prompt = self::build_prompt( $payload );

		$response = wp_remote_post(
			$url,
			array(
				'timeout' => 30,
				'headers' => array( 'Content-Type' => 'application/json' ),
				'body'    => wp_json_encode(
					array(
						'contents' => array(
							array(
								'parts' => array(
									array( 'text' => $prompt ),
								),
							),
						),
					)
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code = wp_remote_retrieve_response_code( $response );
		$body = wp_remote_retrieve_body( $response );

		if ( 400 === $code || 403 === $code ) {
			return new WP_Error(
				'gitpress_editor_gemini_auth',
				__( 'Gemini rejected the API key. Check your Settings.', 'gitpress-editor' ),
				array( 'status' => 502 )
			);
		}
		if ( 429 === $code ) {
			return new WP_Error(
				'gitpress_editor_gemini_rate_limited',
				__( 'Gemini rate limit reached. Please wait and retry.', 'gitpress-editor' ),
				array( 'status' => 429 )
			);
		}
		if ( $code < 200 || $code >= 300 ) {
			return new WP_Error(
				'gitpress_editor_gemini_error',
				/* translators: %d: HTTP status code */
				sprintf( __( 'Gemini API error (HTTP %d).', 'gitpress-editor' ), $code ),
				array( 'status' => 502 )
			);
		}

		$data = json_decode( $body, true );
		$text = isset( $data['candidates'][0]['content']['parts'][0]['text'] )
			? $data['candidates'][0]['content']['parts'][0]['text']
			: '';
		if ( '' === $text ) {
			return new WP_Error(
				'gitpress_editor_gemini_empty',
				__( 'Gemini returned an empty response.', 'gitpress-editor' ),
				array( 'status' => 502 )
			);
		}
		return $text;
	}

	/**
	 * Build the instruction prompt for the structured edit format (v0.2.0).
	 *
	 * The AI is expected to return ONLY these four optional fields per edit:
	 *   - text           : replacement text (plain string, no HTML)
	 *   - style          : { "property": "value" } using CSS kebab-case
	 *   - add_classes    : [class, class, ...] from the allowed list
	 *   - remove_classes : [class, class, ...]
	 *
	 * HTML in the `text` field is stripped server-side. CSS properties not in
	 * the element's allowed_styles list are dropped. Classes not in
	 * allowed_classes are dropped.
	 *
	 * @param array $payload Payload with edits + instruction.
	 * @return string
	 */
	private static function build_prompt( $payload ) {
		$json = wp_json_encode( $payload, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT );

		$intro = __( 'You are a content editing assistant for a WordPress site. You will modify elements identified by data-edit paths.', 'gitpress-editor' );

		$rules = __( 'Rules you must follow strictly:', 'gitpress-editor' ) . "\n"
			. "1. Return a single JSON object matching the schema below — no markdown, no prose outside the JSON.\n"
			. "2. Each edit MUST include a `path` field copied verbatim from the request.\n"
			. "3. For text changes, use the `text` field with PLAIN STRINGS ONLY. Never include HTML tags in `text`.\n"
			. "4. For ANY CSS property change (color, font-size, font-weight, background, etc.), you MUST use the `style` field. NEVER use add_classes for color or font changes — there are no utility classes for colors. Example: {\"style\":{\"color\":\"red\"}}.\n"
			. "5. `add_classes` is ONLY for pre-defined visual effects listed in allowed_classes (gradient, marker, glow etc.). If the class name is not in allowed_classes, it will be silently dropped and have no effect.\n"
			. "6. If you need to remove an existing class, list it in `remove_classes`.\n"
			. "7. NEVER invent class names like 'gp-text-black', 'gp-text-red', 'gp-color-blue', etc. They do not exist. Use `style` instead.\n"
			. "8. Only include the fields you are actually changing — omit anything unchanged.\n"
			. "9. If the instruction is ambiguous, prefer minimal changes per element.\n"
			. "10. You MUST return an edit entry for EVERY element in the request. Do not skip any element. The user explicitly selected all of them for editing.\n"
			. "11. To delete/remove an element entirely, set `delete: true`. Do NOT use style display:none — use `delete` instead.\n"
			. "12. If an element currently has a text-effect class that paints the text with a gradient or transparent fill (e.g. gp-text-rainbow, gp-text-gradient-brand, gp-text-gradient-warm, gp-text-gradient-cool, gp-text-gradient-sunset, gp-text-outline) and the user asks you to change the color, you MUST list the existing effect class in `remove_classes` in the same edit. Otherwise the new color will be invisible because the gradient/clip keeps painting over it.";

		$schema = __( 'Response schema (strict JSON):', 'gitpress-editor' ) . "\n"
			. "{\n"
			. "  \"edits\": [\n"
			. "    {\n"
			. "      \"path\": \"string, REQUIRED, copied from request\",\n"
			. "      \"text\": \"string, OPTIONAL, plain text only\",\n"
			. "      \"style\": { \"css-prop\": \"value\", ... } (OPTIONAL),\n"
			. "      \"add_classes\": [\"class-name\", ...] (OPTIONAL),\n"
			. "      \"remove_classes\": [\"class-name\", ...] (OPTIONAL),\n"
			. "      \"delete\": true (OPTIONAL, removes the element entirely),\n"
			. "      \"reason\": \"short rationale in the user's language\"\n"
			. "    }\n"
			. "  ]\n"
			. "}";

		$examples = __( 'Examples:', 'gitpress-editor' ) . "\n"
			. "• Text change: {\"path\":\"home.hero.title\",\"text\":\"New Title\",\"reason\":\"shortened\"}\n"
			. "• Color change: {\"path\":\"home.hero.title\",\"style\":{\"color\":\"#ff5722\"},\"reason\":\"emphasis\"}\n"
			. "• Bold + red: {\"path\":\"home.hero.title\",\"style\":{\"color\":\"#ff0000\",\"font-weight\":\"bold\"},\"reason\":\"stand out\"}\n"
			. "• Rainbow via preset class: {\"path\":\"home.services.title\",\"add_classes\":[\"gp-text-rainbow\"],\"reason\":\"colorful\"}\n"
			. "• Remove a class and add another: {\"path\":\"home.hero.desc\",\"remove_classes\":[\"gp-text-muted\"],\"add_classes\":[\"gp-text-bold\"]}\n"
			. "• Delete element: {\"path\":\"home.hero.badge\",\"delete\":true,\"reason\":\"user requested removal\"}";

		return $intro . "\n\n" . $rules . "\n\n" . $schema . "\n\n" . $examples . "\n\n"
			. "--- Edit request (read `allowed_classes` and `allowed_styles` per element) ---\n"
			. $json;
	}
}
