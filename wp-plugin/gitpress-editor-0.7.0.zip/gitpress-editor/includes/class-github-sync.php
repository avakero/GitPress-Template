<?php
/**
 * GitHub sync: write the updated post back to the Git repo so Git stays
 * in sync with WordPress after a plugin-side edit.
 *
 * Commits are made with `[skip ci]` in the message so that they do NOT
 * re-trigger the sync workflow that would redundantly push the same
 * content back to WordPress.
 *
 * @package GitPress_Editor
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class GitPress_Editor_GitHub_Sync {

	const API_BASE     = 'https://api.github.com';
	const HTTP_TIMEOUT = 10;
	const USER_AGENT   = 'GitPress-Editor';

	/**
	 * Push the updated post to GitHub.
	 *
	 * @param int $post_id Post that was just updated.
	 * @return true|WP_Error|null true on success, WP_Error on failure, null if disabled.
	 */
	public static function sync_post( $post_id ) {
		$options = GitPress_Editor_Plugin::get_options();
		if ( empty( $options['github_sync_enabled'] ) || '1' !== (string) $options['github_sync_enabled'] ) {
			return null;
		}

		$token       = GitPress_Editor_Security::decrypt( (string) ( $options['github_token'] ?? '' ) );
		$repo        = trim( (string) ( $options['github_repo'] ?? '' ) );
		$branch      = trim( (string) ( $options['github_branch'] ?? 'main' ) );
		$path_prefix = trim( (string) ( $options['github_path_prefix'] ?? 'content' ), '/' );

		if ( '' === $token ) {
			return new WP_Error( 'gitpress_editor_github_no_token', __( 'GitHub token is not set.', 'gitpress-editor' ) );
		}
		if ( ! preg_match( '#^[A-Za-z0-9_.\-]+/[A-Za-z0-9_.\-]+$#', $repo ) ) {
			return new WP_Error( 'gitpress_editor_github_bad_repo', __( 'GitHub repo must be in the form owner/name.', 'gitpress-editor' ) );
		}
		if ( '' === $branch ) {
			$branch = 'main';
		}

		$post = get_post( $post_id );
		if ( ! $post ) {
			return new WP_Error( 'gitpress_editor_github_no_post', __( 'Post not found.', 'gitpress-editor' ) );
		}
		$slug = $post->post_name;
		if ( '' === $slug ) {
			return new WP_Error( 'gitpress_editor_github_no_slug', __( 'Post has no slug; cannot map to a Git file.', 'gitpress-editor' ) );
		}

		$path = $path_prefix . '/' . $post->post_type . '/' . $slug . '.html';

		$existing = self::fetch_file( $token, $repo, $branch, $path );
		if ( is_wp_error( $existing ) ) {
			return $existing;
		}

		if ( null === $existing ) {
			$content_raw = self::build_new_file( $post );
			$sha         = null;
		} else {
			$content_raw = self::replace_body( $existing['content'], $post );
			$sha         = $existing['sha'];
		}

		$commit_title = sprintf( 'chore(wp-sync): %s', $slug );
		$commit_body  = sprintf(
			"Applied edits from GitPress Editor plugin (post_id=%d).\n\n[skip ci]",
			$post->ID
		);
		$message = $commit_title . "\n\n" . $commit_body;

		return self::put_file( $token, $repo, $branch, $path, $content_raw, $sha, $message, $options );
	}

	/**
	 * Fetch a file from GitHub.
	 *
	 * @param string $token  OAuth / PAT.
	 * @param string $repo   owner/name.
	 * @param string $branch Branch name.
	 * @param string $path   File path in the repo.
	 * @return array{content:string,sha:string}|null|WP_Error Array with decoded content + sha, null if the file does not exist, WP_Error on transport errors.
	 */
	private static function fetch_file( $token, $repo, $branch, $path ) {
		$url = sprintf(
			'%s/repos/%s/contents/%s?ref=%s',
			self::API_BASE,
			$repo,
			self::encode_path( $path ),
			rawurlencode( $branch )
		);

		$response = wp_remote_get(
			$url,
			array(
				'timeout' => self::HTTP_TIMEOUT,
				'headers' => self::build_headers( $token ),
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code = wp_remote_retrieve_response_code( $response );
		if ( 404 === $code ) {
			return null;
		}
		if ( $code < 200 || $code >= 300 ) {
			return new WP_Error(
				'gitpress_editor_github_fetch_failed',
				/* translators: 1: HTTP status, 2: response body snippet */
				sprintf( __( 'GitHub fetch failed (HTTP %1$d): %2$s', 'gitpress-editor' ), $code, self::snippet( $response ) )
			);
		}

		$body = wp_remote_retrieve_body( $response );
		$data = json_decode( $body, true );
		if ( ! is_array( $data ) || ! isset( $data['content'] ) || ! isset( $data['sha'] ) ) {
			return new WP_Error( 'gitpress_editor_github_bad_json', __( 'Unexpected response from GitHub.', 'gitpress-editor' ) );
		}
		$decoded = base64_decode( str_replace( array( "\n", "\r" ), '', $data['content'] ), true );
		if ( false === $decoded ) {
			return new WP_Error( 'gitpress_editor_github_bad_base64', __( 'Could not decode file from GitHub.', 'gitpress-editor' ) );
		}
		return array(
			'content' => $decoded,
			'sha'     => (string) $data['sha'],
		);
	}

	/**
	 * Create or update a file on GitHub via the Contents API.
	 *
	 * @param string      $token   PAT.
	 * @param string      $repo    owner/name.
	 * @param string      $branch  Branch.
	 * @param string      $path    File path.
	 * @param string      $content Raw file content (UTF-8).
	 * @param string|null $sha     Existing sha (null for new file).
	 * @param string      $message Commit message.
	 * @param array       $options Plugin options (for committer info).
	 * @return true|WP_Error
	 */
	private static function put_file( $token, $repo, $branch, $path, $content, $sha, $message, $options ) {
		$url = sprintf(
			'%s/repos/%s/contents/%s',
			self::API_BASE,
			$repo,
			self::encode_path( $path )
		);

		$payload = array(
			'message' => $message,
			'content' => base64_encode( $content ),
			'branch'  => $branch,
		);
		if ( null !== $sha ) {
			$payload['sha'] = $sha;
		}

		$committer_name  = trim( (string) ( $options['github_committer_name'] ?? '' ) );
		$committer_email = trim( (string) ( $options['github_committer_email'] ?? '' ) );
		if ( '' !== $committer_name && '' !== $committer_email ) {
			$payload['committer'] = array(
				'name'  => $committer_name,
				'email' => $committer_email,
			);
		}

		$response = wp_remote_request(
			$url,
			array(
				'method'  => 'PUT',
				'timeout' => self::HTTP_TIMEOUT,
				'headers' => array_merge(
					self::build_headers( $token ),
					array( 'Content-Type' => 'application/json' )
				),
				'body'    => wp_json_encode( $payload ),
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}
		$code = wp_remote_retrieve_response_code( $response );
		if ( $code < 200 || $code >= 300 ) {
			return new WP_Error(
				'gitpress_editor_github_put_failed',
				/* translators: 1: HTTP status, 2: response body snippet */
				sprintf( __( 'GitHub commit failed (HTTP %1$d): %2$s', 'gitpress-editor' ), $code, self::snippet( $response ) )
			);
		}
		return true;
	}

	/**
	 * Replace the body of a front-matter'd file with the post's new content,
	 * and refresh the `modified:` field in the front matter.
	 *
	 * @param string  $existing Existing file content from Git.
	 * @param WP_Post $post     Post whose content should overwrite the body.
	 * @return string New file content.
	 */
	private static function replace_body( $existing, $post ) {
		if ( preg_match( '/\A---\r?\n(.*?)\r?\n---\r?\n(.*)\z/s', $existing, $m ) ) {
			$frontmatter = self::update_modified( $m[1], $post );
			return "---\n" . $frontmatter . "\n---\n\n" . $post->post_content . "\n";
		}
		// File exists but has no front matter — rebuild fully.
		return self::build_new_file( $post );
	}

	/**
	 * Update (or append) the `modified:` key in a YAML front matter block.
	 *
	 * @param string  $frontmatter Raw YAML front matter (without delimiters).
	 * @param WP_Post $post        Post.
	 * @return string
	 */
	private static function update_modified( $frontmatter, $post ) {
		$modified = self::iso_gmt( $post->post_modified_gmt );
		$line     = 'modified: "' . $modified . '"';
		if ( preg_match( '/^modified:.*$/m', $frontmatter ) ) {
			return preg_replace( '/^modified:.*$/m', $line, $frontmatter );
		}
		return rtrim( $frontmatter, "\r\n" ) . "\n" . $line;
	}

	/**
	 * Build a full file (front matter + body) for a post that does not yet
	 * exist in the Git repo.
	 *
	 * @param WP_Post $post Post.
	 * @return string
	 */
	private static function build_new_file( $post ) {
		$title     = self::yaml_escape( $post->post_title );
		$slug      = self::yaml_escape( $post->post_name );
		$status    = self::yaml_escape( $post->post_status );
		$date      = self::iso_gmt( $post->post_date_gmt );
		$modified  = self::iso_gmt( $post->post_modified_gmt );
		$post_type = self::yaml_escape( $post->post_type );

		$fm  = "---\n";
		$fm .= 'post_id: ' . (int) $post->ID . "\n";
		$fm .= 'post_type: "' . $post_type . "\"\n";
		$fm .= 'slug: "' . $slug . "\"\n";
		$fm .= 'title: "' . $title . "\"\n";
		$fm .= 'status: "' . $status . "\"\n";
		$fm .= 'date: "' . $date . "\"\n";
		$fm .= 'modified: "' . $modified . "\"\n";
		$fm .= "---\n\n";
		$fm .= $post->post_content . "\n";
		return $fm;
	}

	/**
	 * Escape a string for use inside a double-quoted YAML scalar.
	 *
	 * @param string $s Raw.
	 * @return string
	 */
	private static function yaml_escape( $s ) {
		return str_replace( array( '\\', '"' ), array( '\\\\', '\\"' ), (string) $s );
	}

	/**
	 * Convert a GMT datetime string ("Y-m-d H:i:s") into ISO 8601 UTC.
	 *
	 * @param string $gmt MySQL datetime (GMT).
	 * @return string
	 */
	private static function iso_gmt( $gmt ) {
		if ( empty( $gmt ) || '0000-00-00 00:00:00' === $gmt ) {
			return gmdate( 'Y-m-d\TH:i:s\Z' );
		}
		$ts = strtotime( $gmt . ' UTC' );
		if ( false === $ts ) {
			return gmdate( 'Y-m-d\TH:i:s\Z' );
		}
		return gmdate( 'Y-m-d\TH:i:s\Z', $ts );
	}

	/**
	 * Percent-encode each segment of a path, preserving `/` separators.
	 *
	 * @param string $path File path.
	 * @return string
	 */
	private static function encode_path( $path ) {
		$parts = explode( '/', $path );
		foreach ( $parts as $i => $p ) {
			$parts[ $i ] = rawurlencode( $p );
		}
		return implode( '/', $parts );
	}

	/**
	 * Build GitHub API request headers.
	 *
	 * @param string $token PAT.
	 * @return array<string,string>
	 */
	private static function build_headers( $token ) {
		return array(
			'Accept'               => 'application/vnd.github+json',
			'Authorization'        => 'Bearer ' . $token,
			'X-GitHub-Api-Version' => '2022-11-28',
			'User-Agent'           => self::USER_AGENT,
		);
	}

	/**
	 * Extract a short snippet of an API error response for logging.
	 *
	 * @param array $response wp_remote_* response.
	 * @return string
	 */
	private static function snippet( $response ) {
		$body = (string) wp_remote_retrieve_body( $response );
		$data = json_decode( $body, true );
		if ( is_array( $data ) && isset( $data['message'] ) ) {
			return (string) $data['message'];
		}
		if ( mb_strlen( $body ) > 200 ) {
			$body = mb_substr( $body, 0, 200 ) . '…';
		}
		return $body;
	}
}
