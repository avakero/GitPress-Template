<?php
/**
 * Manifest loader.
 *
 * Merges two layers of editable-element manifests:
 *
 *   1. Bundled baseline (GITPRESS_EDITOR_DIR . 'manifests/*.json')
 *      Built from config/editables/*.yaml at package time by wp-plugin/build.py.
 *      Ships the default ruleset for reference sites (e.g. pixelcraft).
 *
 *   2. Site-specific overrides (wp-content/uploads/gitpress-manifests/*.json)
 *      Loaded at runtime. Skill-generated sites should drop their own
 *      manifests here so the plugin can curate editing for that specific
 *      structure. Entries here OVERRIDE the bundled baseline for the same
 *      data-edit path. See scripts/generate_manifest.py for a tool that
 *      produces matching JSON from any HTML directory.
 *
 * Resolution order (later wins):
 *   bundled baseline → uploads/gitpress-manifests → `gitpress_editor_manifests` filter
 *
 * @package GitPress_Editor
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class GitPress_Editor_Manifest_Loader {

	const CACHE_KEY    = 'gitpress_editor_manifests_v1';
	const CACHE_TTL    = 900; // 15 minutes

	/**
	 * Bundled preset class catalogue (kept in sync with assets/css/presets.css).
	 * Exposed to the AI as the "available classes" hint when no manifest entry
	 * exists for a given path. With this list the AI can pick the right preset
	 * by name instead of guessing.
	 *
	 * @var string[]
	 */
	const PRESET_CLASSES = array(
		'gp-text-rainbow',
		'gp-text-gradient-brand',
		'gp-text-gradient-warm',
		'gp-text-gradient-cool',
		'gp-text-gradient-sunset',
		'gp-text-marker-yellow',
		'gp-text-marker-pink',
		'gp-text-marker-cyan',
		'gp-text-glow',
		'gp-text-glow-warm',
		'gp-text-outline',
		'gp-text-bold',
		'gp-text-semibold',
		'gp-text-normal',
		'gp-text-italic',
		'gp-text-underline',
		'gp-text-strike',
		'gp-text-uppercase',
		'gp-text-primary',
		'gp-text-secondary',
		'gp-text-accent',
		'gp-text-success',
		'gp-text-danger',
		'gp-text-muted',
		'gp-text-white',
		'gp-text-black',
		'gp-text-xs', 'gp-text-sm', 'gp-text-md', 'gp-text-lg',
		'gp-text-xl', 'gp-text-2xl', 'gp-text-3xl', 'gp-text-4xl',
		'gp-text-left', 'gp-text-center', 'gp-text-right',
	);

	private static $loaded = null;

	/**
	 * Return the merged manifest map (path → entry).
	 *
	 * @return array
	 */
	public static function all() {
		if ( null !== self::$loaded ) {
			return self::$loaded;
		}

		$cached = get_transient( self::CACHE_KEY );
		if ( false !== $cached && is_array( $cached ) ) {
			self::$loaded = $cached;
			return $cached;
		}

		$merged = array();

		// Layer 1: bundled baseline shipped with the plugin.
		self::merge_json_dir( $merged, GITPRESS_EDITOR_DIR . 'manifests' );

		// Layer 2: site-specific manifests dropped into uploads/gitpress-manifests/.
		// Used by skill-generated sites to curate editing for their own structure.
		// Overrides bundled entries for the same data-edit path.
		$site_dir = self::site_manifests_dir();
		if ( $site_dir ) {
			self::merge_json_dir( $merged, $site_dir );
		}

		// Layer 3: programmatic override via filter (highest precedence).
		$merged = apply_filters( 'gitpress_editor_manifests', $merged );

		set_transient( self::CACHE_KEY, $merged, self::CACHE_TTL );
		self::$loaded = $merged;
		return $merged;
	}

	/**
	 * Fetch a single entry by its data-edit path.
	 *
	 * @param string $path data-edit value (e.g. "home.hero.title").
	 * @return array|null Entry definition or null if unknown.
	 */
	public static function get( $path ) {
		$all = self::all();
		return isset( $all[ $path ] ) ? $all[ $path ] : null;
	}

	/**
	 * Get allowed_styles for a path.
	 *
	 * Returns "*" (wildcard) when:
	 *   - the path is not in any bundled manifest (permissive default), OR
	 *   - the manifest entry explicitly sets allowed_styles: "*".
	 * Otherwise returns the explicit array from the manifest.
	 *
	 * @param string $path data-edit path.
	 * @return string|array "*" or list of property names.
	 */
	public static function allowed_styles( $path ) {
		$entry = self::get( $path );
		// Unknown path → permissive default. Allows new sites to work without
		// rebuilding the plugin just to ship a manifest.
		if ( ! $entry || ! isset( $entry['allowed_styles'] ) ) {
			return '*';
		}
		$value = $entry['allowed_styles'];
		if ( '*' === $value ) {
			return '*';
		}
		return is_array( $value ) ? $value : array();
	}

	/**
	 * Get allowed_classes for a path.
	 *
	 * Returns "*" (wildcard) when the path is unknown. Returns the explicit
	 * array when the manifest declares one (which may be empty to forbid
	 * all class additions).
	 *
	 * @param string $path data-edit path.
	 * @return string|array "*" or list of class names.
	 */
	public static function allowed_classes( $path ) {
		$entry = self::get( $path );
		if ( ! $entry || ! isset( $entry['allowed_classes'] ) ) {
			return '*';
		}
		return is_array( $entry['allowed_classes'] ) ? $entry['allowed_classes'] : array();
	}

	/**
	 * Flush the cache. Call after shipping new manifests.
	 */
	public static function flush() {
		delete_transient( self::CACHE_KEY );
		self::$loaded = null;
	}

	/**
	 * Resolve the site-specific manifests directory.
	 *
	 * Defaults to wp-content/uploads/gitpress-manifests/. Sites can relocate
	 * via the `gitpress_editor_site_manifests_dir` filter (return an absolute
	 * path or empty string to disable).
	 *
	 * @return string|null Absolute path, or null when disabled/unavailable.
	 */
	public static function site_manifests_dir() {
		$default = '';
		if ( function_exists( 'wp_upload_dir' ) ) {
			$uploads = wp_upload_dir( null, false );
			if ( is_array( $uploads ) && ! empty( $uploads['basedir'] ) ) {
				$default = trailingslashit( $uploads['basedir'] ) . 'gitpress-manifests';
			}
		}

		$dir = apply_filters( 'gitpress_editor_site_manifests_dir', $default );
		if ( ! is_string( $dir ) || '' === $dir ) {
			return null;
		}
		return $dir;
	}

	/**
	 * Merge every *.json in $dir into $target (path → entry map).
	 *
	 * Later files override earlier ones on key collision, consistent with
	 * array_merge semantics. Invalid JSON and unreadable files are skipped.
	 *
	 * @param array  $target Manifest map passed by reference.
	 * @param string $dir    Directory to scan.
	 * @return void
	 */
	private static function merge_json_dir( array &$target, $dir ) {
		if ( ! is_string( $dir ) || '' === $dir || ! is_dir( $dir ) ) {
			return;
		}
		$files = glob( rtrim( $dir, '/\\' ) . '/*.json' );
		if ( ! is_array( $files ) ) {
			return;
		}
		sort( $files ); // deterministic order across platforms
		foreach ( $files as $file ) {
			$raw = file_get_contents( $file );
			if ( false === $raw ) {
				continue;
			}
			$data = json_decode( $raw, true );
			if ( is_array( $data ) ) {
				// Entries are keyed by the full dot path which is globally unique.
				$target = array_merge( $target, $data );
			}
		}
	}
}
