<?php
/**
 * Main plugin bootstrap class.
 *
 * @package GitPress_Editor
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Singleton that wires up all sub-components.
 */
class GitPress_Editor_Plugin {

	/**
	 * Instance.
	 *
	 * @var GitPress_Editor_Plugin|null
	 */
	private static $instance = null;

	/**
	 * Get the singleton.
	 *
	 * @return GitPress_Editor_Plugin
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Wire hooks.
	 */
	public function init() {
		GitPress_Editor_Settings::instance()->init();
		GitPress_Editor_Rest_Api::instance()->init();
		GitPress_Editor_Frontend::instance()->init();
	}

	/**
	 * Read plugin options with defaults.
	 *
	 * @return array
	 */
	public static function get_options() {
		$defaults = array(
			'model'                  => 'gemini-2.0-flash',
			'enabled_roles'          => array( 'administrator', 'editor' ),
			'show_button'            => '1',
			'use_trial_key'          => '1',
			'user_api_key'           => '',
			'github_sync_enabled'    => '0',
			'github_token'           => '',
			'github_repo'            => '',
			'github_branch'          => 'main',
			'github_path_prefix'     => 'content',
			'github_committer_name'  => 'GitPress Editor',
			'github_committer_email' => '',
		);
		$options  = get_option( 'gitpress_editor_options', array() );
		return wp_parse_args( is_array( $options ) ? $options : array(), $defaults );
	}
}
