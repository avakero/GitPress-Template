<?php
/**
 * Per-user rate limiter backed by transients.
 *
 * @package GitPress_Editor
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class GitPress_Editor_Rate_Limiter {

	/**
	 * Check and consume one unit from the bucket for the current user.
	 *
	 * @param string $bucket Bucket name (e.g. "ai-edit", "apply").
	 * @param int    $limit  Max requests allowed in the window.
	 * @param int    $window Window in seconds.
	 * @return true|WP_Error True on success, WP_Error if rate limited.
	 */
	public static function check( $bucket, $limit, $window ) {
		$user_id = get_current_user_id();
		if ( ! $user_id ) {
			return new WP_Error(
				'gitpress_editor_not_logged_in',
				__( 'Not logged in.', 'gitpress-editor' ),
				array( 'status' => 401 )
			);
		}

		$key   = 'gitpress_editor_rl_' . $bucket . '_' . $user_id;
		$count = (int) get_transient( $key );

		if ( $count >= $limit ) {
			return new WP_Error(
				'gitpress_editor_rate_limited',
				__( 'Too many requests. Please slow down.', 'gitpress-editor' ),
				array( 'status' => 429 )
			);
		}

		set_transient( $key, $count + 1, $window );
		return true;
	}
}
