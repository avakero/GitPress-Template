<?php
/**
 * REST API routes for the GitPress Editor plugin.
 *
 * Edit payload shape (new in 0.2.0):
 *   {
 *     "edits": [
 *       {
 *         "path": "home.hero.title",
 *         "text": "New text content",
 *         "style": { "color": "#ff0000" },
 *         "add_classes": ["gp-text-rainbow"],
 *         "remove_classes": ["gp-text-muted"]
 *       }
 *     ],
 *     "instruction": "Freeform user instruction (for /ai-edit only)"
 *   }
 *
 * Text-based replacement is gone. All updates are scoped to elements
 * with matching `data-edit` attributes.
 *
 * @package GitPress_Editor
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class GitPress_Editor_Rest_Api {

	/** Hard limits on incoming payloads. */
	const MAX_EDITS_PER_REQUEST = 30;
	const MAX_INSTRUCTION_LEN   = 2000;
	const MAX_TEXT_LEN          = 20000;
	const MAX_PATH_LEN          = 128;
	const MAX_STYLE_VALUE_LEN   = 500;
	const MAX_STYLES_PER_EDIT   = 30;
	const MAX_CLASSES_PER_EDIT  = 20;
	const MAX_ATTR_VALUE_LEN    = 2000;

	/**
	 * Whitelisted HTML attribute keys that the apply endpoint will accept
	 * from the `attrs` field. Used by the media picker flow for images and
	 * links.
	 */
	const ALLOWED_ATTR_KEYS = array(
		'src', 'alt', 'srcset', 'sizes', 'width', 'height',
		'href', 'title', 'target', 'rel',
	);

	/** Whitelist of tags that can be inserted as new elements. */
	const ALLOWED_INSERT_TAGS = array( 'img', 'p', 'h2', 'h3', 'hr' );

	/** Valid insertion positions relative to the reference element. */
	const ALLOWED_INSERT_POSITIONS = array( 'before', 'after', 'inside' );

	/** Permitted characters in a new_path (data-edit for inserted element). */
	const INSERT_PATH_RE = '/^[a-zA-Z0-9_.\\-]+$/';

	/** Rate limits per user. */
	const AI_EDIT_LIMIT   = 30;
	const AI_EDIT_WINDOW  = 60;
	const APPLY_LIMIT     = 20;
	const APPLY_WINDOW    = 60;

	/** Patterns. */
	const CLASS_RE = '/^[a-zA-Z][a-zA-Z0-9_-]*$/';
	const CSS_PROP_RE = '/^-?[a-z][a-z0-9-]*$/';

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	public function init() {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}

	public function register_routes() {
		$namespace = GitPress_Editor_Security::REST_NAMESPACE;
		$perm      = array( 'GitPress_Editor_Security', 'rest_permission_callback' );

		register_rest_route(
			$namespace,
			'/ai-edit',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'handle_ai_edit' ),
				'permission_callback' => $perm,
				'args'                => array(
					'edits'       => array( 'required' => true ),
					'instruction' => array( 'required' => false ),
				),
			)
		);

		register_rest_route(
			$namespace,
			'/apply',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'handle_apply' ),
				'permission_callback' => $perm,
				'args'                => array(
					'post_id' => array(
						'required' => true,
						'type'     => 'integer',
					),
					'edits'   => array( 'required' => true ),
				),
			)
		);

		register_rest_route(
			$namespace,
			'/resolve',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'handle_resolve' ),
				'permission_callback' => $perm,
			)
		);
	}

	/**
	 * POST /ai-edit — send selected elements + instruction to Gemini.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function handle_ai_edit( $request ) {
		$limited = GitPress_Editor_Rate_Limiter::check( 'ai-edit', self::AI_EDIT_LIMIT, self::AI_EDIT_WINDOW );
		if ( is_wp_error( $limited ) ) {
			return $limited;
		}

		$edits = self::sanitize_edits_for_ai( $request->get_param( 'edits' ) );
		if ( is_wp_error( $edits ) ) {
			return $edits;
		}

		$instruction_raw = (string) $request->get_param( 'instruction' );
		$instruction     = sanitize_textarea_field( $instruction_raw );
		if ( mb_strlen( $instruction ) > self::MAX_INSTRUCTION_LEN ) {
			$instruction = mb_substr( $instruction, 0, self::MAX_INSTRUCTION_LEN );
		}

		$payload  = array(
			'edits'       => $edits,
			'instruction' => $instruction,
		);
		$response = GitPress_Editor_Gemini_Client::generate_edits( $payload );

		if ( is_wp_error( $response ) ) {
			return $response;
		}
		return rest_ensure_response( array( 'text' => $response ) );
	}

	/**
	 * POST /apply — apply structured edits to a post.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function handle_apply( $request ) {
		$limited = GitPress_Editor_Rate_Limiter::check( 'apply', self::APPLY_LIMIT, self::APPLY_WINDOW );
		if ( is_wp_error( $limited ) ) {
			return $limited;
		}

		$post_id = (int) $request->get_param( 'post_id' );
		if ( $post_id <= 0 || ! get_post( $post_id ) ) {
			return new WP_Error(
				'gitpress_editor_post_not_found',
				__( 'Post not found.', 'gitpress-editor' ),
				array( 'status' => 404 )
			);
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return new WP_Error(
				'gitpress_editor_cannot_edit_post',
				__( 'You cannot edit this post.', 'gitpress-editor' ),
				array( 'status' => 403 )
			);
		}

		$edits = self::sanitize_edits_for_apply( $request->get_param( 'edits' ) );
		if ( is_wp_error( $edits ) ) {
			return $edits;
		}

		$result = GitPress_Editor_Content_Updater::apply( $post_id, $edits );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$github = self::run_github_sync( $post_id );

		return rest_ensure_response(
			array(
				'post_id'     => $post_id,
				'applied'     => $result['applied'],
				'skipped'     => $result['skipped'],
				'github_sync' => $github,
			)
		);
	}

	/**
	 * Best-effort push of the updated post back to GitHub. Never throws —
	 * a sync failure must not roll back a successful WordPress update.
	 *
	 * @param int $post_id Updated post.
	 * @return array Status payload shaped as:
	 *   { enabled: bool, ok?: bool, error?: string }
	 */
	private static function run_github_sync( $post_id ) {
		$result = GitPress_Editor_GitHub_Sync::sync_post( $post_id );
		if ( null === $result ) {
			return array( 'enabled' => false );
		}
		if ( is_wp_error( $result ) ) {
			error_log( '[GitPress Editor] GitHub sync failed: ' . $result->get_error_message() );
			return array(
				'enabled' => true,
				'ok'      => false,
				'error'   => $result->get_error_message(),
			);
		}
		return array(
			'enabled' => true,
			'ok'      => true,
		);
	}

	/**
	 * GET /resolve?url=... — resolve a page URL to its post ID.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function handle_resolve( $request ) {
		$url = esc_url_raw( (string) $request->get_param( 'url' ) );
		if ( '' === $url ) {
			return new WP_Error(
				'gitpress_editor_missing_url',
				__( 'Missing url parameter.', 'gitpress-editor' ),
				array( 'status' => 400 )
			);
		}

		$req_host  = wp_parse_url( $url, PHP_URL_HOST );
		$home_host = wp_parse_url( home_url( '/' ), PHP_URL_HOST );
		if ( ! $req_host || ! $home_host || strtolower( $req_host ) !== strtolower( $home_host ) ) {
			return new WP_Error(
				'gitpress_editor_foreign_url',
				__( 'URL does not belong to this site.', 'gitpress-editor' ),
				array( 'status' => 400 )
			);
		}

		$post_id = url_to_postid( $url );
		if ( ! $post_id ) {
			$front = (int) get_option( 'page_on_front' );
			if ( $front ) {
				$home = untrailingslashit( home_url( '/' ) );
				if ( untrailingslashit( $url ) === $home ) {
					$post_id = $front;
				}
			}
		}

		if ( ! $post_id ) {
			return new WP_Error(
				'gitpress_editor_unresolved',
				__( 'Could not resolve the URL to a post.', 'gitpress-editor' ),
				array( 'status' => 404 )
			);
		}

		$post = get_post( $post_id );
		return rest_ensure_response(
			array(
				'post_id'   => $post_id,
				'post_type' => $post ? $post->post_type : '',
				'title'     => $post ? $post->post_title : '',
			)
		);
	}

	// ==================================================================
	// Sanitization
	// ==================================================================

	/**
	 * Sanitize incoming edits that will be sent to the AI.
	 *
	 * @param mixed $edits Raw.
	 * @return array|WP_Error
	 */
	public static function sanitize_edits_for_ai( $edits ) {
		if ( ! is_array( $edits ) || empty( $edits ) ) {
			return new WP_Error(
				'gitpress_editor_empty_edits',
				__( 'No edits supplied.', 'gitpress-editor' ),
				array( 'status' => 400 )
			);
		}
		if ( count( $edits ) > self::MAX_EDITS_PER_REQUEST ) {
			return new WP_Error(
				'gitpress_editor_too_many_edits',
				/* translators: %d: max edits per request */
				sprintf( __( 'Too many edits in one request (max %d).', 'gitpress-editor' ), self::MAX_EDITS_PER_REQUEST ),
				array( 'status' => 400 )
			);
		}

		$clean = array();
		foreach ( $edits as $edit ) {
			if ( ! is_array( $edit ) ) {
				continue;
			}
			$path = isset( $edit['path'] ) ? sanitize_text_field( (string) $edit['path'] ) : '';
			if ( '' === $path ) {
				continue;
			}
			if ( mb_strlen( $path ) > self::MAX_PATH_LEN ) {
				$path = mb_substr( $path, 0, self::MAX_PATH_LEN );
			}

			$tag    = isset( $edit['tag'] ) ? strtolower( sanitize_key( (string) $edit['tag'] ) ) : '';
			$text   = isset( $edit['text'] ) ? (string) $edit['text'] : '';
			$text   = wp_strip_all_tags( $text );
			if ( mb_strlen( $text ) > self::MAX_TEXT_LEN ) {
				$text = mb_substr( $text, 0, self::MAX_TEXT_LEN );
			}

			// Read manifest entry to enrich AI context.
			// Unknown paths fall back to the bundled preset catalogue so the AI
			// can still pick a class by name instead of guessing.
			$manifest = GitPress_Editor_Manifest_Loader::get( $path );
			if ( $manifest && isset( $manifest['allowed_classes'] ) && is_array( $manifest['allowed_classes'] ) ) {
				$allowed_classes = array_values( $manifest['allowed_classes'] );
			} else {
				$allowed_classes = GitPress_Editor_Manifest_Loader::PRESET_CLASSES;
			}
			$allowed_styles = $manifest && isset( $manifest['allowed_styles'] )
				? $manifest['allowed_styles']
				: '*';

			$clean[] = array(
				'path'            => $path,
				'tag'             => $tag,
				'text'            => $text,
				'label'           => isset( $manifest['label'] ) ? (string) $manifest['label'] : '',
				'type'            => isset( $manifest['type'] ) ? (string) $manifest['type'] : '',
				'allowed_classes' => $allowed_classes,
				'allowed_styles'  => $allowed_styles,
			);
		}

		if ( empty( $clean ) ) {
			return new WP_Error(
				'gitpress_editor_empty_edits',
				__( 'No edits supplied.', 'gitpress-editor' ),
				array( 'status' => 400 )
			);
		}
		return $clean;
	}

	/**
	 * Sanitize incoming edits that will be applied to a post.
	 *
	 * Enforces the manifest-declared allowed_styles / allowed_classes. Any
	 * CSS property or class name outside the allowed list is silently dropped.
	 *
	 * @param mixed $edits Raw.
	 * @return array|WP_Error
	 */
	public static function sanitize_edits_for_apply( $edits ) {
		if ( ! is_array( $edits ) || empty( $edits ) ) {
			return new WP_Error(
				'gitpress_editor_empty_edits',
				__( 'No edits supplied.', 'gitpress-editor' ),
				array( 'status' => 400 )
			);
		}
		if ( count( $edits ) > self::MAX_EDITS_PER_REQUEST ) {
			return new WP_Error(
				'gitpress_editor_too_many_edits',
				/* translators: %d: max edits per request */
				sprintf( __( 'Too many edits in one request (max %d).', 'gitpress-editor' ), self::MAX_EDITS_PER_REQUEST ),
				array( 'status' => 400 )
			);
		}

		$clean = array();
		foreach ( $edits as $edit ) {
			if ( ! is_array( $edit ) || empty( $edit['path'] ) ) {
				continue;
			}
			$path = sanitize_text_field( (string) $edit['path'] );
			if ( mb_strlen( $path ) > self::MAX_PATH_LEN ) {
				$path = mb_substr( $path, 0, self::MAX_PATH_LEN );
			}

			$allowed_styles  = GitPress_Editor_Manifest_Loader::allowed_styles( $path );
			$allowed_classes = GitPress_Editor_Manifest_Loader::allowed_classes( $path );

			$entry = array( 'path' => $path );

			// text
			if ( isset( $edit['text'] ) && is_string( $edit['text'] ) ) {
				$text = wp_strip_all_tags( $edit['text'] );
				if ( mb_strlen( $text ) > self::MAX_TEXT_LEN ) {
					$text = mb_substr( $text, 0, self::MAX_TEXT_LEN );
				}
				$entry['text'] = $text;
			}

			// style
			if ( isset( $edit['style'] ) && is_array( $edit['style'] ) ) {
				$cleaned = self::filter_style( $edit['style'], $allowed_styles );
				if ( ! empty( $cleaned ) ) {
					$entry['style'] = $cleaned;
				}
			}

			// add_classes
			if ( isset( $edit['add_classes'] ) && is_array( $edit['add_classes'] ) ) {
				$cleaned = self::filter_classes( $edit['add_classes'], $allowed_classes );
				if ( ! empty( $cleaned ) ) {
					$entry['add_classes'] = $cleaned;
				}
			}

			// remove_classes
			if ( isset( $edit['remove_classes'] ) && is_array( $edit['remove_classes'] ) ) {
				$cleaned = array();
				$count   = 0;
				foreach ( $edit['remove_classes'] as $cls ) {
					if ( $count >= self::MAX_CLASSES_PER_EDIT ) {
						break;
					}
					$cls = (string) $cls;
					if ( preg_match( self::CLASS_RE, $cls ) ) {
						$cleaned[] = $cls;
						$count++;
					}
				}
				if ( ! empty( $cleaned ) ) {
					$entry['remove_classes'] = $cleaned;
				}
			}

			// attrs (used by the media picker flow for images and links)
			if ( isset( $edit['attrs'] ) && is_array( $edit['attrs'] ) ) {
				$cleaned_attrs = self::filter_attrs( $edit['attrs'] );
				if ( ! empty( $cleaned_attrs ) ) {
					$entry['attrs'] = $cleaned_attrs;
				}
			}

			// insert (create a new element relative to the reference path)
			if ( isset( $edit['insert'] ) && is_array( $edit['insert'] ) ) {
				$cleaned_insert = self::filter_insert( $edit['insert'] );
				if ( ! empty( $cleaned_insert ) ) {
					$entry['insert'] = $cleaned_insert;
				}
			}

			// Drop edits that have no actionable field after sanitization.
			if ( count( $entry ) > 1 ) {
				$clean[] = $entry;
			}
		}

		if ( empty( $clean ) ) {
			return new WP_Error(
				'gitpress_editor_empty_edits',
				__( 'No edits supplied.', 'gitpress-editor' ),
				array( 'status' => 400 )
			);
		}
		return $clean;
	}

	/**
	 * Filter a style map by the allowed_styles whitelist.
	 *
	 * @param array        $styles  Raw.
	 * @param string|array $allowed "*" or list of property names.
	 * @return array<string,string>
	 */
	private static function filter_style( $styles, $allowed ) {
		$result = array();
		$count  = 0;
		foreach ( $styles as $prop => $value ) {
			if ( $count >= self::MAX_STYLES_PER_EDIT ) {
				break;
			}
			$prop  = strtolower( trim( (string) $prop ) );
			$value = trim( (string) $value );
			if ( '' === $prop || '' === $value ) {
				continue;
			}
			if ( ! preg_match( self::CSS_PROP_RE, $prop ) ) {
				continue;
			}
			// Length limit.
			if ( mb_strlen( $value ) > self::MAX_STYLE_VALUE_LEN ) {
				continue;
			}
			// Blacklist dangerous patterns regardless of wildcard.
			if ( self::is_dangerous_value( $value ) ) {
				continue;
			}
			// Check whitelist.
			if ( '*' !== $allowed ) {
				if ( ! is_array( $allowed ) || ! in_array( $prop, $allowed, true ) ) {
					continue;
				}
			}
			$result[ $prop ] = $value;
			$count++;
		}
		return $result;
	}

	/**
	 * Filter a class list by the allowed_classes whitelist.
	 *
	 * @param array        $classes Raw.
	 * @param string|array $allowed "*" (wildcard) or whitelist array.
	 * @return string[]
	 */
	private static function filter_classes( $classes, $allowed ) {
		$result = array();
		$count  = 0;
		$wildcard = ( '*' === $allowed );
		foreach ( $classes as $cls ) {
			if ( $count >= self::MAX_CLASSES_PER_EDIT ) {
				break;
			}
			$cls = (string) $cls;
			if ( ! preg_match( self::CLASS_RE, $cls ) ) {
				continue;
			}
			if ( ! $wildcard ) {
				if ( ! is_array( $allowed ) || ! in_array( $cls, $allowed, true ) ) {
					continue;
				}
			}
			$result[] = $cls;
			$count++;
		}
		return array_values( array_unique( $result ) );
	}

	/**
	 * Filter an incoming attrs map by the whitelist.
	 *
	 * URL-valued attributes (src, srcset, href) are passed through
	 * esc_url_raw and must use http/https/protocol-relative/relative or
	 * data:image schemes. Text-valued attributes (alt, title, target,
	 * rel, sizes, width, height) are sanitize_text_field'd and length
	 * limited.
	 *
	 * @param array $attrs Raw attrs from the client.
	 * @return array<string,string>
	 */
	private static function filter_attrs( $attrs ) {
		$result = array();
		$url_keys = array( 'src', 'href', 'srcset' );
		foreach ( $attrs as $key => $value ) {
			$key = strtolower( trim( (string) $key ) );
			if ( '' === $key || ! in_array( $key, self::ALLOWED_ATTR_KEYS, true ) ) {
				continue;
			}
			$value = (string) $value;
			if ( mb_strlen( $value ) > self::MAX_ATTR_VALUE_LEN ) {
				continue;
			}
			if ( in_array( $key, $url_keys, true ) ) {
				// Allow empty value to mean "remove attribute".
				if ( '' === $value ) {
					$result[ $key ] = '';
					continue;
				}
				// For srcset we let esc_url_raw through each candidate.
				if ( 'srcset' === $key ) {
					$candidates = array();
					foreach ( explode( ',', $value ) as $item ) {
						$item = trim( $item );
						if ( '' === $item ) {
							continue;
						}
						$parts = preg_split( '/\s+/', $item, 2 );
						$url   = isset( $parts[0] ) ? esc_url_raw( $parts[0] ) : '';
						if ( '' === $url || self::is_dangerous_url( $url ) ) {
							continue;
						}
						$candidates[] = isset( $parts[1] ) ? ( $url . ' ' . sanitize_text_field( $parts[1] ) ) : $url;
					}
					if ( ! empty( $candidates ) ) {
						$result[ $key ] = implode( ', ', $candidates );
					}
					continue;
				}
				$safe = esc_url_raw( $value );
				if ( '' === $safe || self::is_dangerous_url( $safe ) ) {
					continue;
				}
				$result[ $key ] = $safe;
			} else {
				$result[ $key ] = sanitize_text_field( $value );
			}
		}
		return $result;
	}

	/**
	 * Sanitize an insertion spec.
	 *
	 * Required keys: tag, position, new_path.
	 * Optional: text (p/h2/h3), attrs (img — must include a non-empty src).
	 *
	 * @param array $spec Raw spec.
	 * @return array Cleaned spec, or empty array on validation failure.
	 */
	private static function filter_insert( $spec ) {
		$tag = isset( $spec['tag'] ) ? strtolower( sanitize_key( (string) $spec['tag'] ) ) : '';
		if ( ! in_array( $tag, self::ALLOWED_INSERT_TAGS, true ) ) {
			return array();
		}
		$position = isset( $spec['position'] ) ? strtolower( (string) $spec['position'] ) : '';
		if ( ! in_array( $position, self::ALLOWED_INSERT_POSITIONS, true ) ) {
			return array();
		}
		$new_path = isset( $spec['new_path'] ) ? sanitize_text_field( (string) $spec['new_path'] ) : '';
		if ( '' === $new_path || mb_strlen( $new_path ) > self::MAX_PATH_LEN ) {
			return array();
		}
		if ( ! preg_match( self::INSERT_PATH_RE, $new_path ) ) {
			return array();
		}

		$out = array(
			'tag'      => $tag,
			'position' => $position,
			'new_path' => $new_path,
		);

		if ( in_array( $tag, array( 'p', 'h2', 'h3' ), true ) ) {
			$text = isset( $spec['text'] ) ? wp_strip_all_tags( (string) $spec['text'] ) : '';
			if ( mb_strlen( $text ) > self::MAX_TEXT_LEN ) {
				$text = mb_substr( $text, 0, self::MAX_TEXT_LEN );
			}
			$out['text'] = $text;
		}

		if ( 'img' === $tag ) {
			$raw_attrs = ( isset( $spec['attrs'] ) && is_array( $spec['attrs'] ) ) ? $spec['attrs'] : array();
			$cleaned   = self::filter_attrs( $raw_attrs );
			if ( empty( $cleaned['src'] ) ) {
				return array();
			}
			$out['attrs'] = $cleaned;
		}

		return $out;
	}

	/**
	 * Reject URLs that use disallowed schemes.
	 *
	 * @param string $url URL candidate.
	 * @return bool
	 */
	private static function is_dangerous_url( $url ) {
		$lower = strtolower( trim( $url ) );
		if ( '' === $lower ) {
			return true;
		}
		// Allow protocol-relative and relative URLs.
		if ( strpos( $lower, '//' ) === 0 || strpos( $lower, '/' ) === 0 || strpos( $lower, './' ) === 0 || strpos( $lower, '../' ) === 0 ) {
			return false;
		}
		// Allow http(s) and data:image.
		if ( strpos( $lower, 'http://' ) === 0 || strpos( $lower, 'https://' ) === 0 ) {
			return false;
		}
		if ( strpos( $lower, 'data:image/' ) === 0 ) {
			return false;
		}
		return true;
	}

	/**
	 * Reject CSS values that could escape normal styling.
	 *
	 * @param string $value CSS value.
	 * @return bool
	 */
	private static function is_dangerous_value( $value ) {
		$lower = strtolower( $value );
		if ( false !== strpos( $lower, 'javascript:' ) ) {
			return true;
		}
		if ( false !== strpos( $lower, 'expression(' ) ) {
			return true;
		}
		if ( false !== strpos( $lower, 'behavior:' ) ) {
			return true;
		}
		if ( preg_match( '/url\s*\(\s*[\'"]?\s*javascript:/i', $value ) ) {
			return true;
		}
		if ( false !== strpos( $value, '@import' ) ) {
			return true;
		}
		return false;
	}
}
