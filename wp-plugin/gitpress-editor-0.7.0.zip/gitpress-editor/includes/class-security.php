<?php
/**
 * Security helpers: capability checks, nonce helpers, API key encryption.
 *
 * @package GitPress_Editor
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class GitPress_Editor_Security {

	const NONCE_ACTION = 'gitpress_editor_nonce';
	const REST_NAMESPACE = 'gitpress/v1';

	/**
	 * Does the current user have permission to use the editor?
	 *
	 * @return bool
	 */
	public static function current_user_can_edit() {
		if ( ! is_user_logged_in() ) {
			return false;
		}
		$options = GitPress_Editor_Plugin::get_options();
		$roles   = isset( $options['enabled_roles'] ) && is_array( $options['enabled_roles'] )
			? $options['enabled_roles']
			: array( 'administrator', 'editor' );

		$user = wp_get_current_user();
		if ( ! $user || empty( $user->roles ) ) {
			return false;
		}

		foreach ( (array) $user->roles as $role ) {
			if ( in_array( $role, $roles, true ) ) {
				return current_user_can( 'edit_pages' ) || current_user_can( 'edit_posts' );
			}
		}
		return false;
	}

	/**
	 * REST permission callback: verify nonce + capability.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return bool|WP_Error
	 */
	public static function rest_permission_callback( $request ) {
		$nonce = $request->get_header( 'X-WP-Nonce' );
		if ( ! $nonce || ! wp_verify_nonce( $nonce, 'wp_rest' ) ) {
			return new WP_Error(
				'gitpress_editor_invalid_nonce',
				__( 'Invalid or missing nonce.', 'gitpress-editor' ),
				array( 'status' => 403 )
			);
		}
		if ( ! self::current_user_can_edit() ) {
			return new WP_Error(
				'gitpress_editor_forbidden',
				__( 'You do not have permission to use the editor.', 'gitpress-editor' ),
				array( 'status' => 403 )
			);
		}
		return true;
	}

	/**
	 * Derive a per-site encryption key from WordPress salts.
	 *
	 * @return string 32-byte key.
	 */
	private static function get_encryption_key() {
		$material = '';
		if ( defined( 'AUTH_KEY' ) ) {
			$material .= AUTH_KEY;
		}
		if ( defined( 'SECURE_AUTH_KEY' ) ) {
			$material .= SECURE_AUTH_KEY;
		}
		if ( '' === $material ) {
			// Fallback — this should never happen on a real WordPress install.
			$material = wp_salt( 'auth' );
		}
		return hash( 'sha256', $material, true );
	}

	/**
	 * Encrypt a string with AES-256-GCM (falls back to a simpler scheme if sodium unavailable).
	 *
	 * @param string $plaintext Plain text.
	 * @return string Base64-encoded ciphertext.
	 */
	public static function encrypt( $plaintext ) {
		if ( '' === $plaintext ) {
			return '';
		}
		if ( function_exists( 'openssl_encrypt' ) ) {
			$key    = self::get_encryption_key();
			$iv     = openssl_random_pseudo_bytes( 12 );
			$tag    = '';
			$cipher = openssl_encrypt( $plaintext, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag );
			if ( false === $cipher ) {
				return '';
			}
			return base64_encode( $iv . $tag . $cipher );
		}
		return base64_encode( $plaintext );
	}

	/**
	 * Decrypt a base64 ciphertext produced by encrypt().
	 *
	 * @param string $ciphertext Base64.
	 * @return string Plain text, or empty string on failure.
	 */
	public static function decrypt( $ciphertext ) {
		if ( '' === $ciphertext ) {
			return '';
		}
		$raw = base64_decode( $ciphertext, true );
		if ( false === $raw ) {
			return '';
		}
		if ( function_exists( 'openssl_decrypt' ) && strlen( $raw ) > 28 ) {
			$key    = self::get_encryption_key();
			$iv     = substr( $raw, 0, 12 );
			$tag    = substr( $raw, 12, 16 );
			$cipher = substr( $raw, 28 );
			$plain  = openssl_decrypt( $cipher, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag );
			return false === $plain ? '' : $plain;
		}
		return $raw;
	}
}
