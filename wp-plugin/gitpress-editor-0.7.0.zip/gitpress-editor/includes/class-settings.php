<?php
/**
 * Admin settings page.
 *
 * @package GitPress_Editor
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class GitPress_Editor_Settings {

	const OPTION_KEY = 'gitpress_editor_options';
	const PAGE_SLUG  = 'gitpress-editor';

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	public function init() {
		add_action( 'admin_menu', array( $this, 'register_menu' ) );
		add_action( 'admin_init', array( $this, 'register_settings' ) );
	}

	public function register_menu() {
		add_options_page(
			__( 'GitPress Editor', 'gitpress-editor' ),
			__( 'GitPress Editor', 'gitpress-editor' ),
			'manage_options',
			self::PAGE_SLUG,
			array( $this, 'render_page' )
		);
	}

	public function register_settings() {
		register_setting(
			'gitpress_editor_group',
			self::OPTION_KEY,
			array(
				'sanitize_callback' => array( $this, 'sanitize_options' ),
				'default'           => array(),
			)
		);
	}

	/**
	 * Sanitize + encrypt user-supplied API key before storing.
	 *
	 * @param array $input Raw form input.
	 * @return array
	 */
	public function sanitize_options( $input ) {
		$clean   = array();
		$allowed_models = array( 'gemini-2.0-flash', 'gemini-2.5-pro', 'gemini-2.5-flash' );

		$clean['model'] = isset( $input['model'] ) && in_array( $input['model'], $allowed_models, true )
			? $input['model']
			: 'gemini-2.0-flash';

		$allowed_roles = array( 'administrator', 'editor', 'author', 'contributor' );
		$roles         = isset( $input['enabled_roles'] ) && is_array( $input['enabled_roles'] )
			? array_values( array_intersect( $allowed_roles, $input['enabled_roles'] ) )
			: array( 'administrator', 'editor' );
		$clean['enabled_roles'] = $roles;

		$clean['show_button']   = ! empty( $input['show_button'] ) ? '1' : '0';
		$clean['use_trial_key'] = ! empty( $input['use_trial_key'] ) ? '1' : '0';

		// Handle the user API key field:
		// - If empty and the placeholder was not changed, keep the existing encrypted value.
		// - If cleared explicitly, remove it.
		// - If a new value is supplied, encrypt and store.
		$existing = get_option( self::OPTION_KEY, array() );
		$existing_key = isset( $existing['user_api_key'] ) ? $existing['user_api_key'] : '';

		if ( isset( $input['user_api_key_action'] ) && 'clear' === $input['user_api_key_action'] ) {
			$clean['user_api_key'] = '';
		} elseif ( isset( $input['user_api_key'] ) && '' !== trim( $input['user_api_key'] ) ) {
			$clean['user_api_key'] = GitPress_Editor_Security::encrypt( sanitize_text_field( $input['user_api_key'] ) );
		} else {
			$clean['user_api_key'] = $existing_key;
		}

		// GitHub sync settings.
		$clean['github_sync_enabled'] = ! empty( $input['github_sync_enabled'] ) ? '1' : '0';

		$repo = isset( $input['github_repo'] ) ? sanitize_text_field( $input['github_repo'] ) : '';
		$clean['github_repo'] = preg_match( '#^[A-Za-z0-9_.\-]+/[A-Za-z0-9_.\-]+$#', $repo ) ? $repo : '';

		$branch = isset( $input['github_branch'] ) ? sanitize_text_field( $input['github_branch'] ) : '';
		$clean['github_branch'] = preg_match( '#^[A-Za-z0-9_./\-]+$#', $branch ) ? $branch : 'main';

		$prefix = isset( $input['github_path_prefix'] ) ? sanitize_text_field( $input['github_path_prefix'] ) : 'content';
		$prefix = trim( $prefix, '/' );
		$clean['github_path_prefix'] = preg_match( '#^[A-Za-z0-9_./\-]+$#', $prefix ) ? $prefix : 'content';

		$committer_name = isset( $input['github_committer_name'] ) ? sanitize_text_field( $input['github_committer_name'] ) : '';
		$clean['github_committer_name'] = '' !== $committer_name ? $committer_name : 'GitPress Editor';

		$committer_email = isset( $input['github_committer_email'] ) ? sanitize_email( $input['github_committer_email'] ) : '';
		$clean['github_committer_email'] = $committer_email;

		$existing_token = isset( $existing['github_token'] ) ? $existing['github_token'] : '';
		if ( isset( $input['github_token_action'] ) && 'clear' === $input['github_token_action'] ) {
			$clean['github_token'] = '';
		} elseif ( isset( $input['github_token'] ) && '' !== trim( $input['github_token'] ) ) {
			$clean['github_token'] = GitPress_Editor_Security::encrypt( sanitize_text_field( $input['github_token'] ) );
		} else {
			$clean['github_token'] = $existing_token;
		}

		return $clean;
	}

	public function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$options         = GitPress_Editor_Plugin::get_options();
		$has_user_key    = ! empty( $options['user_api_key'] );
		$has_github_token = ! empty( $options['github_token'] );
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'GitPress Editor', 'gitpress-editor' ); ?></h1>
			<p><?php esc_html_e( 'Visual AI-powered content editor for WordPress. Configure the plugin behavior below.', 'gitpress-editor' ); ?></p>

			<form method="post" action="options.php">
				<?php settings_fields( 'gitpress_editor_group' ); ?>

				<table class="form-table" role="presentation">
					<tbody>
						<tr>
							<th scope="row"><?php esc_html_e( 'Gemini Model', 'gitpress-editor' ); ?></th>
							<td>
								<select name="<?php echo esc_attr( self::OPTION_KEY ); ?>[model]">
									<option value="gemini-2.0-flash" <?php selected( $options['model'], 'gemini-2.0-flash' ); ?>>gemini-2.0-flash</option>
									<option value="gemini-2.5-flash" <?php selected( $options['model'], 'gemini-2.5-flash' ); ?>>gemini-2.5-flash</option>
									<option value="gemini-2.5-pro" <?php selected( $options['model'], 'gemini-2.5-pro' ); ?>>gemini-2.5-pro</option>
								</select>
							</td>
						</tr>

						<tr>
							<th scope="row"><?php esc_html_e( 'Enabled Roles', 'gitpress-editor' ); ?></th>
							<td>
								<?php
								$roles_labels = array(
									'administrator' => __( 'Administrator', 'gitpress-editor' ),
									'editor'        => __( 'Editor', 'gitpress-editor' ),
									'author'        => __( 'Author', 'gitpress-editor' ),
									'contributor'   => __( 'Contributor', 'gitpress-editor' ),
								);
								foreach ( $roles_labels as $role_slug => $role_label ) :
									$checked = in_array( $role_slug, (array) $options['enabled_roles'], true );
									?>
									<label style="display:block;margin-bottom:4px;">
										<input type="checkbox" name="<?php echo esc_attr( self::OPTION_KEY ); ?>[enabled_roles][]" value="<?php echo esc_attr( $role_slug ); ?>" <?php checked( $checked ); ?>>
										<?php echo esc_html( $role_label ); ?>
									</label>
								<?php endforeach; ?>
								<p class="description"><?php esc_html_e( 'Only users with one of the selected roles will see the editor.', 'gitpress-editor' ); ?></p>
							</td>
						</tr>

						<tr>
							<th scope="row"><?php esc_html_e( 'Floating Button', 'gitpress-editor' ); ?></th>
							<td>
								<label>
									<input type="checkbox" name="<?php echo esc_attr( self::OPTION_KEY ); ?>[show_button]" value="1" <?php checked( '1', $options['show_button'] ); ?>>
									<?php esc_html_e( 'Show the editor launcher on the frontend.', 'gitpress-editor' ); ?>
								</label>
							</td>
						</tr>

						<tr>
							<th scope="row"><?php esc_html_e( 'Trial API Key', 'gitpress-editor' ); ?></th>
							<td>
								<label>
									<input type="checkbox" name="<?php echo esc_attr( self::OPTION_KEY ); ?>[use_trial_key]" value="1" <?php checked( '1', $options['use_trial_key'] ); ?>>
									<?php esc_html_e( 'Use the bundled trial API key when no personal key is set.', 'gitpress-editor' ); ?>
								</label>
								<p class="description"><?php esc_html_e( 'The trial key has a low quota and is shared across installations. For production use, enter your own key below.', 'gitpress-editor' ); ?></p>
							</td>
						</tr>

						<tr>
							<th scope="row"><?php esc_html_e( 'Your Gemini API Key', 'gitpress-editor' ); ?></th>
							<td>
								<input type="password" name="<?php echo esc_attr( self::OPTION_KEY ); ?>[user_api_key]" value="" autocomplete="off" class="regular-text" placeholder="<?php echo $has_user_key ? esc_attr__( '(already set — leave blank to keep)', 'gitpress-editor' ) : 'AIza...'; ?>">
								<?php if ( $has_user_key ) : ?>
									<label style="display:block;margin-top:6px;">
										<input type="checkbox" name="<?php echo esc_attr( self::OPTION_KEY ); ?>[user_api_key_action]" value="clear">
										<?php esc_html_e( 'Clear the stored API key', 'gitpress-editor' ); ?>
									</label>
								<?php endif; ?>
								<p class="description"><?php esc_html_e( 'Stored encrypted. You can obtain a key at Google AI Studio.', 'gitpress-editor' ); ?></p>
							</td>
						</tr>
					</tbody>
				</table>

				<h2><?php esc_html_e( 'GitHub Sync', 'gitpress-editor' ); ?></h2>
				<p class="description" style="max-width:720px;">
					<?php esc_html_e( 'Mirror every plugin-side edit back to your Git repository so the Git source of truth stays in sync with WordPress. Commits include "[skip ci]" so they do NOT trigger the deploy workflow.', 'gitpress-editor' ); ?>
				</p>

				<table class="form-table" role="presentation">
					<tbody>
						<tr>
							<th scope="row"><?php esc_html_e( 'Enable GitHub Sync', 'gitpress-editor' ); ?></th>
							<td>
								<label>
									<input type="checkbox" name="<?php echo esc_attr( self::OPTION_KEY ); ?>[github_sync_enabled]" value="1" <?php checked( '1', $options['github_sync_enabled'] ); ?>>
									<?php esc_html_e( 'Push edits back to Git after they are applied to WordPress.', 'gitpress-editor' ); ?>
								</label>
							</td>
						</tr>

						<tr>
							<th scope="row"><?php esc_html_e( 'GitHub Personal Access Token', 'gitpress-editor' ); ?></th>
							<td>
								<input type="password" name="<?php echo esc_attr( self::OPTION_KEY ); ?>[github_token]" value="" autocomplete="off" class="regular-text" placeholder="<?php echo $has_github_token ? esc_attr__( '(already set — leave blank to keep)', 'gitpress-editor' ) : 'ghp_... or github_pat_...'; ?>">
								<?php if ( $has_github_token ) : ?>
									<label style="display:block;margin-top:6px;">
										<input type="checkbox" name="<?php echo esc_attr( self::OPTION_KEY ); ?>[github_token_action]" value="clear">
										<?php esc_html_e( 'Clear the stored token', 'gitpress-editor' ); ?>
									</label>
								<?php endif; ?>
								<p class="description"><?php esc_html_e( 'Needs "Contents: Read & Write" permission on the target repo. Stored encrypted.', 'gitpress-editor' ); ?></p>
							</td>
						</tr>

						<tr>
							<th scope="row"><?php esc_html_e( 'Repository', 'gitpress-editor' ); ?></th>
							<td>
								<input type="text" name="<?php echo esc_attr( self::OPTION_KEY ); ?>[github_repo]" value="<?php echo esc_attr( $options['github_repo'] ); ?>" class="regular-text" placeholder="owner/repo">
								<p class="description"><?php esc_html_e( 'The Git repo that stores your content, e.g. "avakero/GitPress".', 'gitpress-editor' ); ?></p>
							</td>
						</tr>

						<tr>
							<th scope="row"><?php esc_html_e( 'Branch', 'gitpress-editor' ); ?></th>
							<td>
								<input type="text" name="<?php echo esc_attr( self::OPTION_KEY ); ?>[github_branch]" value="<?php echo esc_attr( $options['github_branch'] ); ?>" class="regular-text" placeholder="main">
							</td>
						</tr>

						<tr>
							<th scope="row"><?php esc_html_e( 'Content Path Prefix', 'gitpress-editor' ); ?></th>
							<td>
								<input type="text" name="<?php echo esc_attr( self::OPTION_KEY ); ?>[github_path_prefix]" value="<?php echo esc_attr( $options['github_path_prefix'] ); ?>" class="regular-text" placeholder="content">
								<p class="description"><?php esc_html_e( 'Files are written to {prefix}/{post_type}/{slug}.html (default: "content").', 'gitpress-editor' ); ?></p>
							</td>
						</tr>

						<tr>
							<th scope="row"><?php esc_html_e( 'Committer Name', 'gitpress-editor' ); ?></th>
							<td>
								<input type="text" name="<?php echo esc_attr( self::OPTION_KEY ); ?>[github_committer_name]" value="<?php echo esc_attr( $options['github_committer_name'] ); ?>" class="regular-text">
							</td>
						</tr>

						<tr>
							<th scope="row"><?php esc_html_e( 'Committer Email', 'gitpress-editor' ); ?></th>
							<td>
								<input type="email" name="<?php echo esc_attr( self::OPTION_KEY ); ?>[github_committer_email]" value="<?php echo esc_attr( $options['github_committer_email'] ); ?>" class="regular-text" placeholder="bot@example.com">
								<p class="description"><?php esc_html_e( 'If left blank, GitHub will attribute commits to the token owner.', 'gitpress-editor' ); ?></p>
							</td>
						</tr>
					</tbody>
				</table>

				<?php submit_button(); ?>
			</form>
		</div>
		<?php
	}
}
