=== GitPress Editor ===
Contributors: avakero
Tags: editor, ai, gemini, visual-editor, content, mobile
Requires at least: 5.6
Tested up to: 6.5
Requires PHP: 7.4
Stable tag: 0.5.19
License: MIT
License URI: https://opensource.org/licenses/MIT

Visual AI-powered editor for WordPress. Click any element on the frontend and edit it with Google Gemini — works on desktop, tablet, and mobile.

== Description ==

GitPress Editor adds a mobile-first visual editing layer to any WordPress site. Authenticated users with edit permissions see a floating launcher button on the frontend. Tapping it opens an editor panel that lets them:

* Click elements on the page to select them
* Describe the change in natural language
* Get AI-generated edit suggestions from Google Gemini
* Preview the change inline on the actual page
* Apply the change to WordPress in one tap

Designed to work equally well on desktops, tablets, and smartphones — the mobile layout uses a swipe-to-close bottom sheet, safe-area insets, and automatic resizing when the soft keyboard opens.

**Key features**

* No server-side API key exposure — Gemini calls are proxied through WordPress
* AES-256-GCM encrypted API key storage
* Per-user rate limiting to prevent abuse
* Server-side sanitization with `wp_kses_post` and multi-layer XSS defenses
* Role-based access control (configurable in settings)
* Works on any WordPress site that has REST API access
* Hybrid API key model: ships with a low-quota trial key, clients can enter their own key for production use

**Requirements**

* WordPress 5.6 or later
* PHP 7.4 or later
* A Google Gemini API key (trial key included, or bring your own)
* Browser support: Chrome 90+, Safari 14+, Firefox 88+, Edge 90+

== Installation ==

1. Download the latest release zip from the [GitHub Releases](https://github.com/avakero/GitPress/releases) page.
2. In WordPress admin, go to **Plugins → Add New → Upload Plugin**.
3. Choose the zip file and click **Install Now**.
4. Click **Activate Plugin**.
5. Go to **Settings → GitPress Editor** to configure.

See `docs/INSTALL.md` for detailed setup instructions.

== Frequently Asked Questions ==

= Do I need a Google Gemini API key? =

The plugin ships with a low-quota trial key for evaluation. For production use, obtain your own key from [Google AI Studio](https://aistudio.google.com/) and enter it in **Settings → GitPress Editor → Your Gemini API Key**.

= Is my API key safe? =

Yes. The key is encrypted with AES-256-GCM using a per-site secret derived from WordPress salts, and is never sent to the frontend. All Gemini requests are proxied through WordPress REST API.

= Who can see the editor? =

By default, only users with the **Administrator** or **Editor** role see the floating button. You can enable additional roles (Author, Contributor) in the settings.

= Does this edit the live site? =

Yes. Confirmed edits are written directly to the post using `wp_update_post()`, which creates a revision. You can roll back from the post editor → Revisions if needed.

= What happens if the AI suggests something malicious? =

The plugin runs `wp_kses_post()` on all AI-generated content before writing to the database, and has a client-side sanitizer that strips script/iframe/on* attributes during preview. Malicious markup cannot reach the database or execute in the browser.

= Does this work with page builders like Elementor or Divi? =

Partially. The editor works on any text that appears in the post's `post_content` field. Content managed by page-builder-specific data structures (e.g. Elementor JSON) may not be editable. Standard Gutenberg blocks and classic editor content work perfectly.

= Is there a rate limit? =

Yes: 30 AI requests per minute and 20 apply requests per minute, per user. This prevents runaway costs on the trial key.

= Can I use this with Gutenberg? =

Yes. Gutenberg blocks store their content in `post_content` as HTML with block comments, and the text-based replacement engine works transparently with that format.

= How does it compare to the Chrome extension? =

Both share the same editing logic. The Chrome extension is great for power users and multi-site workflows; this plugin is better for mobile editing and client-owned sites because it requires no extension install and uses the native WordPress authentication.

== Screenshots ==

1. Floating launcher button in the bottom-right of any page.
2. Editor panel opened on desktop — right side drawer with queue, instruction, AI response.
3. Bottom sheet layout on mobile with drag handle.
4. AI suggestion card showing before/after diff.
5. Settings page with model selection and API key input.

== Changelog ==

= 0.5.0 =
* Feature: Individual edit reset — each AI suggestion card now has a × button to remove that single edit and revert the element's preview, while keeping remaining edits applicable.
* UX: Auto-preview (hot-reload). AI suggestions are applied to the page immediately when the response arrives, eliminating the need to click Preview. The edit → review loop is reduced from 3 clicks to 1.
* UX: Preview highlight redesigned — yellow outline replaced with a green left-border and "Preview" label badge, clearly distinguishing preview state from the orange selection highlight.
* Fix: Removing a queue item no longer destroys the AI response. Selection queue and AI edits are now independent.

= 0.3.0 =
* Feature: Image editing via the WordPress Media Library. Click any `<img data-edit="...">` to see a thumbnail in the panel; use the "画像を変更..." button to open the WordPress media picker and select/upload a new image, and the Alt text field to update the alt attribute. Preview and Apply work the same as text/style edits.
* The content updater, REST API, and client preview all accept a new `attrs` field on edits with a whitelist of `src`, `alt`, `srcset`, `sizes`, `width`, `height`, `href`, `title`, `target`, `rel`.
* URL-valued attributes are validated against http/https/relative/data:image schemes; other schemes (including `javascript:`) are rejected.
* `wp_enqueue_media()` is loaded on the frontend for users with `upload_files` capability.

= 0.2.7 =
* UX: While the editor panel is open on desktop/tablet, the `<body>` is pushed left via `margin-right` so page content is no longer hidden behind the panel. All elements become visible and clickable. On mobile the bottom sheet does not cover the sides, so nothing changes there.

= 0.2.6 =
* UX: Moved the "Send to AI" button from the panel footer to directly below the "Edit instruction" textarea, so the write-instruction → send flow is one continuous vertical sequence. Only the "Clear" action remains in the footer.

= 0.2.5 =
* Fix: Hardened Promise chains in `onSend` and `onApply` so `aiInFlight` and the apply button always reset, even if a handler throws. Previously a silent JS error could leave the panel in a "stuck" state where no button could be clicked.
* Errors inside AI response handlers are now logged to the console and shown as red error text in the panel instead of silently breaking the flow.

= 0.2.4 =
* UX: The editor panel is now non-blocking. The page behind the panel stays fully interactive, so you can select elements without closing the panel first.
* UX: On mobile the bottom sheet default height shrunk from 90dvh to 55dvh so the upper half of the page is visible and tappable while the panel is open.
* Removed the full-viewport backdrop that was catching clicks.

= 0.2.3 =
* Improved: When a path has no manifest entry, the AI prompt now receives the full preset class catalogue (`gp-text-rainbow`, `gp-text-gradient-*`, `gp-text-marker-*`, ...) instead of an empty list. AI can now reliably pick the right preset by name (e.g. "make this rainbow" → `gp-text-rainbow`).

= 0.2.2 =
* Fix: Removed `display: inline-block` from gradient text preset classes (`gp-text-rainbow`, `gp-text-gradient-*`). Previously this broke `text-align: center` on headings, causing the text to snap to the left.

= 0.2.1 =
* Fix: Unknown data-edit paths (e.g. new sites without a bundled manifest) now default to permissive allowed_styles: "*" and allowed_classes: "*" instead of rejecting all edits with "No edits supplied".
* Internal: `filter_classes` now supports wildcard whitelist.

= 0.2.0 =
* BREAKING: Edits now target elements by `data-edit` attribute. Pages without these attributes cannot be edited.
* BREAKING: AI response format switched to `{ text, style, add_classes, remove_classes }`.
* Added `Manifest_Loader` that reads bundled JSON manifests for per-element allowed_styles / allowed_classes whitelists.
* Added preset CSS classes (`gp-text-rainbow`, `gp-text-gradient-brand`, `gp-text-marker-yellow`, `gp-text-glow`, etc.) shipped in `assets/css/presets.css`.
* Content updater rewritten with `DOMDocument` for surgical updates.
* Gemini prompt now requests the structured schema and consumes allowed lists.
* Removed 3-tier text replacement fallback and generic element picker.

= 0.1.0 =
* Initial release.
* Visual element selection with hover highlight and tap targeting.
* Google Gemini Flash integration via server-side REST proxy.
* Inline preview with one-click apply / revert.
* Mobile bottom sheet layout with swipe-to-close gesture.
* Soft keyboard handling via visualViewport API.
* Safe-area insets for iPhone notch and home indicator.
* AES-256-GCM encrypted API key storage.
* Per-user rate limiting on AI and apply endpoints.
* `wp_kses_post` server-side sanitization of AI output.
* Role-based access control (Administrator / Editor by default).
* i18n support with English source and `.pot` template.
* Hybrid API key strategy (trial key + user-supplied key).

== Upgrade Notice ==

= 0.2.0 =
Breaking change: pages must contain `data-edit` attributes. Review your site content before upgrading from 0.1.0.

= 0.1.0 =
Initial release.
