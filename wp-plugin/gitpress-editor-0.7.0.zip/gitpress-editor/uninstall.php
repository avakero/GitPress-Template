<?php
/**
 * Uninstall routine: remove plugin options.
 *
 * @package GitPress_Editor
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

delete_option( 'gitpress_editor_options' );
